﻿# -*- coding: utf-8 -*-
# le \ permet de continuer la ligne précédente à la ligne suivante

# =============================================================================
# importations:

import pygame

from jeu import Jeu
# =============================================================================

# =============================================================================
# code de la boutique

def store(
        screen: pygame.Surface,
        background: pygame.Surface = pygame.transform.scale(
            pygame.image.load("assets/general/fond.jpg"),
            (920, 900)
        ),
        jeu : Jeu = Jeu(),
        run: bool = True
        ) -> bool:

    """fonction qui retourne run, la variable responsable du bouclage général de l'application. \
    Cette fonction affiche la boutique.
    ----
    pre:
        - screen est une surface pygame
        - background est une surface pygame
        - jeu est une instance de Jeu
        - run est un bool
    post:
        - run est un bool
    """

    # =============================================================================
    # importations:

    import fonctions_utiles

    from bouton_selectionnable import Bouton_selectionnable
    # =============================================================================

#   Assertions
    assert type(screen) == pygame.Surface, "screen n'est pas une surface pygame"
    assert type(background) == pygame.Surface, "background n'est pas une surface pygame"
    assert type(jeu) == Jeu, "jeu n'est pas une instance de Jeu"
    assert type(run) == bool, "run n'est pas un bool"

#   initialisation des boutons
    closeButton: Bouton_selectionnable = Bouton_selectionnable(
        "retour au menu principal",
        jeu.get_images().get("return to main Menu")
    )

    ennemi_1: Bouton_selectionnable = Bouton_selectionnable(
        "ennemi_1",
        jeu.get_images().get("ennemi 1")
    )

    ennemi_2: Bouton_selectionnable = Bouton_selectionnable(
        "ennemi_2",
        jeu.get_images().get("ennemi 2")
    )

    ennemi_3: Bouton_selectionnable = Bouton_selectionnable(
        "ennemi_3",
        jeu.get_images().get("ennemi 3")
    )

    ennemi_4: Bouton_selectionnable = Bouton_selectionnable(
        "ennemi_4",
        jeu.get_images().get("ennemi 4")
    )

    ennemi_5: Bouton_selectionnable = Bouton_selectionnable(
        "ennemi_5",
        jeu.get_images().get("ennemi 5")
    )

    ennemi_6: Bouton_selectionnable = Bouton_selectionnable(
        "ennemi_6",
        jeu.get_images().get("ennemi 6")
    )

    ennemi_7: Bouton_selectionnable = Bouton_selectionnable(
        "ennemi_7",
        jeu.get_images().get("ennemi 7")
    )

    avion_1: Bouton_selectionnable = Bouton_selectionnable(
        "avion_1",
        jeu.get_images().get("avion 1")
    )

    avion_2: Bouton_selectionnable = Bouton_selectionnable(
        "avion_2",
        jeu.get_images().get("avion 2")
    )

    avion_3: Bouton_selectionnable = Bouton_selectionnable(
        "avion_3",
        jeu.get_images().get("avion 3")
    )

    avion_4: Bouton_selectionnable = Bouton_selectionnable(
        "avion_4",
        jeu.get_images().get("avion 4")
    )

    avion_5: Bouton_selectionnable = Bouton_selectionnable(
        "avion_5",
        jeu.get_images().get("avion 5")
    )

    avion_6: Bouton_selectionnable = Bouton_selectionnable(
        "avion_6",
        jeu.get_images().get("avion 6")
    )

    avion_7: Bouton_selectionnable = Bouton_selectionnable(
        "avion_7",
        jeu.get_images().get("avion 7")
    )

    avion_8: Bouton_selectionnable = Bouton_selectionnable(
        "avion_8",
        jeu.get_images().get('avion 8')
    )

#   page par défaut
    page: str = "avion"
#   dernier bouton survolé
    last = None
#   dernieres sélections
#   On récupère les chemins des dernières apparences sélectionné des ennemis
    skin: list = fonctions_utiles.get_skins_enn()

#   On crée la liste que nous allons remplir en fonction des sélection
    last_enns_selected = []

#   On cherche pour chaque chemin le bouton / item correspondant
    for i in skin:
        i: str

#       si le chemin est celui de l'item e_1
        if i == ennemi_1.get_image_bank(3):

#           On sélectionne le bouton / item
            ennemi_1.change_to_select()

#           On ajoute cet item à la liste préconcus
            last_enns_selected.append(ennemi_1)

#       sinon si c'est celui de l'item e_2
        elif i == ennemi_2.get_image_bank(3):
            ennemi_2.change_to_select()
            last_enns_selected.append(ennemi_2)

#       même procédé 7x
        elif i == ennemi_3.get_image_bank(3):
            ennemi_3.change_to_select()
            last_enns_selected.append(ennemi_3)

        elif i == ennemi_4.get_image_bank(3):
            ennemi_4.change_to_select()
            last_enns_selected.append(ennemi_4)

        elif i == ennemi_5.get_image_bank(3):
            ennemi_5.change_to_select()
            last_enns_selected.append(ennemi_5)

        elif i == ennemi_6.get_image_bank(3):
            ennemi_6.change_to_select()
            last_enns_selected.append(ennemi_6)

        else:
            ennemi_7.change_to_select()
            last_enns_selected.append(ennemi_7)

#   On cherche maintemant quel avion avait été selectionné

#   On récupère le chemin du dernier avion sélectionné
    skin: str = fonctions_utiles.get_last_skin_avion()

#   si c'est le même chemin que celui de l'item a_1
    if skin == avion_1.get_image_bank(3):

#       On affecte cet item a last_av_selected
        last_av_selected = avion_1

#   même procédé 8x
    elif skin == avion_2.get_image_bank(3):
        last_av_selected = avion_2

    elif skin == avion_3.get_image_bank(3):
        last_av_selected = avion_3

    elif skin == avion_4.get_image_bank(3):
        last_av_selected = avion_4

    elif skin == avion_5.get_image_bank(3):
        last_av_selected = avion_5

    elif skin == avion_6.get_image_bank(3):
        last_av_selected = avion_6

    elif skin == avion_7.get_image_bank(3):
        last_av_selected = avion_7

    else:
        last_av_selected = avion_8

#   On séelection l'item qui corespond au dernier avion sélectionné
    last_av_selected.change_to_select()

#   début de la boucle:
    play = True

#   on charge une image de cadena de 140 par 140 px
    cadenas_140x140 = fonctions_utiles.make_cadenas_image_on_size(140, 140)

#   on lance le bouclage jusqu'a ce qu'on l'arrête
    while play:

#       ===========================================================================
#       affichage des éléments généraux sur l'écran:

#       affichage du fond étoilé
        screen.blit(background, (0, 0))

#       affichage des textes généraux
        fonctions_utiles.add_txt(screen, "BOUTIQUE", 60, (255, 255, 255), (350, 35))
        fonctions_utiles.add_txt(screen, "AVIONS", 40, (255, 255, 255), (200, 115))
        fonctions_utiles.add_txt(screen, "MONSTRES", 40, (255, 255, 255), (620, 115))
        fonctions_utiles.add_txt(screen, "confirmer [ENTER]", 20, (255, 255, 255), (400, screen.get_height() - 23))

#       affichage des lignes de séparation
        pygame.draw.line(screen, (255, 255, 255), (0, 100),
                         (screen.get_width(), 100))
        pygame.draw.line(screen, (255, 255, 255), (0, 150),
                         (screen.get_width(), 150))
        pygame.draw.line(screen, (255, 255, 255), (screen.get_width() // 2, 100),
                         (screen.get_width() // 2, 150))
#       ===========================================================================

        if page == "avion":

#           ===================================================================
#           affichage des différents élements spécifique à cet page

#           gris d'arrière plan pour montrer la page séléctionné, ici, elle
#           couvre la partie de l'avion
            screen.blit(jeu.get_flou(), (0, 100))

#           afficher les apparences bloquées
            screen.blit(cadenas_140x140, (710, 195))
            screen.blit(cadenas_140x140, (490, 385))
            screen.blit(cadenas_140x140, (710, 385))

#           affichage le bouton qui retourne au menu principale
            screen.blit(closeButton.get_image(), (2, 2))

#           affichage des boutons des avions
            screen.blit(avion_1.get_image(), (50, 195))
            screen.blit(avion_2.get_image(), (300, 195))
            screen.blit(avion_3.get_image(), (505, 195))
            screen.blit(avion_4.get_image(), (620, screen.get_width() - 50 - 295))
            screen.blit(avion_5.get_image(), (50, 385))
            screen.blit(avion_6.get_image(), (270, 385))
            screen.blit(avion_7.get_image(), (50, screen.get_width() - 50 - 295))
            screen.blit(avion_8.get_image(), (335, screen.get_width() - 50 - 295))
#           ===================================================================
#           update screen/mise à jour de l'affichage:

            fonctions_utiles.update_screen()
#           ===================================================================

            for event in pygame.event.get():

                if event.type == pygame.QUIT:
#                   on arrête cette boucle interne
                    play = False
#                   on récupère la variable qui permet le bouclage de l'appliction globale et qu'on va retourner à
#                   la fin de la fonction
                    run = False

                elif event.type == pygame.MOUSEMOTION:

#                   on récupère les nouvelles coordonnées de la souris
                    x, y = event.pos

#                   si la souris survol le bouton de retour au menu principal
                    if 2 < x < 235 and 2 < y < 35:
                        closeButton.change_to_overflew()
                        last = closeButton

#                   sinon si la souris survole le bouton de l'avion 1 et qu'il n'est pas sélectionné
                    elif 50 < x < 235 and 195 < y < 335 and not avion_1.get_selected():
#                       on fais les modification pour le statut de survolé
                        avion_1.change_to_overflew()
#                       on stock avion 1 est le bouton sélectionné
                        last = avion_1

#                   même procédé que pour avion 1
                    elif 300 < x < 440 and 195 < y < 335 and not avion_2.get_selected():
                        avion_2.change_to_overflew()
                        last = avion_2

#                   même procédé que pour avion 1
                    elif 505 < x < 645 and 195 < y < 335 and not avion_3.get_selected():
                        avion_3.change_to_overflew()
                        last = avion_3


#                   même procédé que pour avion 1
                    elif 620 < x < 855 and screen.get_width() - 50 - 295 < y < screen.get_width() - 50 and \
                            not avion_4.get_selected():
                        avion_4.change_to_overflew()
                        last = avion_4

#                   même procédé que pour avion 1
                    elif 50 < x < 190 and 385 < y < 525 and not avion_5.get_selected():
                        avion_5.change_to_overflew()
                        last = avion_5

#                   même procédé que pour avion 1
                    elif 270 < x < 410 and 385 < y < 525 and not avion_6.get_selected():
                        avion_6.change_to_overflew()
                        last = avion_6

#                   même procédé que pour avion 1
                    elif 50 < x < 285 and screen.get_width() - 50 - 295 < y < screen.get_width() - 50 and not \
                            avion_7.get_selected():
                        avion_7.change_to_overflew()
                        last = avion_7

#                   même procédé que pour avion 1
                    elif 335 < x < 570 and screen.get_width() - 50 - 295 < y < screen.get_width() - 50 and not \
                            avion_8.get_selected():
                        avion_8.change_to_overflew()
                        last = avion_8

#                   sinon il n'y a pas de bouton survolé donc s'il y avait un bouton survolé enregistrer dans la
#                   variable last, il n'est plus survolé et il faut changer sont statu de normal
                    elif last is not None:
#                       on le remet à l'etat normal
                        last.change_to_norm()
#                       s'il n'y a plus de de bouton sélectionné alors last doit stocké rien
                        last = None

#               s'il y a un mouse button down (un click sur la souris) est qu'il s'agit du bouton
#               1 soit le click gauche
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:

#                   s'il est dans la zone de sélection de la page enneni
                    if screen.get_width() // 2 < x < screen.get_width() and 100 < y < 150:
#                       on passe sur la page ennemi
                        page = "ennemi"

#                   sinon si le bouton pour retourner au menu principal est survolé c'est que le click a été sur lui et
#                   donc on retourne au menu principal
                    elif closeButton.get_overflew():
#                       On arrête la boucle while interne
                        play = False

#                   sinon si c'est le bouton de l'avion 1 qui est sélectionné
                    elif avion_1.get_overflew():
#                       On effectue les modifications du statut
#                       On remet la dernière sélection en normal
                        last_av_selected.change_to_norm()
#                       on sélectionne ce bouton
                        avion_1.change_to_select()
#                       on enregistre dans cet variable que le dernier bouton sélectionné est celui-là
                        last_av_selected = avion_1
#                       on remet retire de last cet item car il est sélectionné
                        last = None

#                   même procédé que pour avion 1
                    elif avion_2.get_overflew():
                        last_av_selected.change_to_norm()
                        avion_2.change_to_select()
                        last_av_selected = avion_2
                        last = None

#                   même procédé que pour avion 1
                    elif avion_3.get_overflew():
                        last_av_selected.change_to_norm()
                        avion_3.change_to_select()
                        last_av_selected = avion_3
                        last = None

#                   même procédé que pour avion 1
                    elif avion_4.get_overflew():
                        last_av_selected.change_to_norm()
                        avion_4.change_to_select()
                        last_av_selected = avion_4
                        last = None

#                   même procédé que pour avion 1
                    elif avion_5.get_overflew():
                        last_av_selected.change_to_norm()
                        avion_5.change_to_select()
                        last_av_selected = avion_5
                        last = None

#                   même procédé que pour avion 1
                    elif avion_6.get_overflew():
                        last_av_selected.change_to_norm()
                        avion_6.change_to_select()
                        last_av_selected = avion_6
                        last = None

#                   même procédé que pour avion 1
                    elif avion_7.get_overflew():
                        last_av_selected.change_to_norm()
                        avion_7.change_to_select()
                        last_av_selected = avion_7
                        last = None

#                   même procédé que pour avion 1
                    elif avion_8.get_overflew():
                        last_av_selected.change_to_norm()
                        avion_8.change_to_select()
                        last_av_selected = avion_8
                        last = None

                elif event.type == pygame.KEYDOWN:

#                   si la touche escape (échap) ou la touche return (Entré)
                    if event.key == pygame.K_ESCAPE \
                            or event.key == pygame.K_RETURN:
#                       on arrête la boucle while interne de la fonction
                        play = False

        else:
#           ===========================================================================
#           affichage éléments

#           afficher les apparences bloqués
            screen.blit(cadenas_140x140, (710, 195))
            screen.blit(cadenas_140x140, (490, 385))
            screen.blit(cadenas_140x140, (710, 385))

#           gris d'arrière plan pour montrer la page séléctionné, ici, elle
#           couvre la partie de l'ennemi
            screen.blit(jeu.get_flou(), (screen.get_width() // 2, 100))

#           afficher le bouton qui retourne au menu principale
            screen.blit(closeButton.get_image(), (2, 2))

#           affichage des bouton des ennemis
            screen.blit(ennemi_1.get_image(), (50, 195))
            screen.blit(ennemi_2.get_image(), (300, 195))
            screen.blit(ennemi_3.get_image(), (50, screen.get_width() - 50 - 295))
            screen.blit(ennemi_4.get_image(), (505, screen.get_width() - 50 - 295))
            screen.blit(ennemi_5.get_image(), (50, 385))
            screen.blit(ennemi_6.get_image(), (270, 385))
            screen.blit(ennemi_7.get_image(), (505, 195))
#           ===========================================================================

#           ==========================================================================
#           mise à jour de l'affichage
            fonctions_utiles.update_screen()
#           ==========================================================================

#           pour chaque événement pris en compte par pygame
            for event in pygame.event.get():

#               si l'utilisateur click sur la croix rouge
                if event.type == pygame.QUIT:
#                   on quitte l'application en arrêtant la boucle interne de la fonction
#                   et la variable la boucle du menu principal que l'on renvoie à la fin de cette fonction
                    play = False
                    run = False

#               on regarde si la souris a été déplacée
                elif event.type == pygame.MOUSEMOTION:

#                   on récupère les coordonnés du nouveau placement de la souris
                    x, y = event.pos

#                   si la souris est sur le bouton de retour au menu principal
                    if 2 < x < 235 and 2 < y < 35:
#                       on utilise la méthode adéquat
#                       on fais les modifications nécessaires au changement de statut
                        closeButton.change_to_overflew()
#                       on change le dernier élément survolé
                        last = closeButton

#                   même procédé pour le bouton ennemi_1 sauf qu'on regarde en plus si le bouton n'est pas déja
#                   séectionné pour ne pas retiré l'image de la sélection pour l'image du survol
                    elif 50 < x < 235 and 195 < y < 335 and not ennemi_1.get_selected():
                        ennemi_1.change_to_overflew()
                        last = ennemi_1

#                   même procédé que l'ennemi 1
                    elif 300 < x < 440 and 195 < y < 335 and not ennemi_2.get_selected():
                        ennemi_2.change_to_overflew()
                        last = ennemi_2

#                   même procédé que l'ennemi 1
                    elif 50 < x < 410 and screen.get_width() - 50 - 295 < y < screen.get_width() - 50 \
                            and not ennemi_3.get_selected():
                        ennemi_3.change_to_overflew()
                        last = ennemi_3

#                   même procédé que l'ennemi 1
                    elif 505 < x < 855 and screen.get_width() - 50 - 295 < y < screen.get_width() - 50 \
                            and not ennemi_4.get_selected():
                        ennemi_4.change_to_overflew()
                        last = ennemi_4

#                   même procédé que l'ennemi 1
                    elif 50 < x < 190 and 385 < y < 525 and not ennemi_5.get_selected():
                        ennemi_5.change_to_overflew()
                        last = ennemi_5

#                   même procédé que l'ennemi 1
                    elif 270 < x < 410 and 385 < y < 525 and not ennemi_6.get_selected():
                        ennemi_6.change_to_overflew()
                        last = ennemi_6

#                   même procédé que l'ennemi 1
                    elif 505 < x < 645 and 195 < y < 335 and not ennemi_7.get_selected():
                        ennemi_7.change_to_overflew()
                        last = ennemi_7


#                   sinon si aucun bouton n'est survolé
#                   on remet le dernier bouton survolé en normal
                    elif last is not None:
#                       on fais les modifications nécessaire
                        last.change_to_norm()
#                       il n'y a plus de bouton séelectionnés
                        last = None

#               si il y un click souris et qu'il s'agit d'un click gauche (button 1)
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:

#                   on récupère les coordonnés du placement du click
                    x, y = event.pos

#                   si le click a lieu dans la zone de sélectil de la page avion
                    if 0 < x < screen.get_width() // 2 and 100 < y < 150:
#                       x: 0 < x < 460
#                       y: 100 < y < 150
#                       on passe sur la page avion
                        page = "avion"

#                   sinon si le bouton de retour au menu pricipale est survolé, il est donc sélectionné
                    elif closeButton.get_overflew():
#                       on return au menu principal
                        play = False

#                   même procédé 7 fois
                    elif ennemi_1.get_overflew():
#                       on sélectionne le bouton
                        ennemi_1.change_to_select()
#                       on actualise les sélections des ennemis
                        last_enns_selected = ennemi_1.reset_condition(last_enns_selected)
#                       on remet last sur None car ce bouton est sélectionné et plus survolé
                        last = None

                    elif ennemi_2.get_overflew():
                        ennemi_2.change_to_select()
                        last_enns_selected = ennemi_2.reset_condition(last_enns_selected)
                        last = None

                    elif ennemi_3.get_overflew():
                        ennemi_3.change_to_select()
                        last_enns_selected = ennemi_3.reset_condition(last_enns_selected)
                        last = None

                    elif ennemi_4.get_overflew():
                        ennemi_4.change_to_select()
                        last_enns_selected = ennemi_4.reset_condition(last_enns_selected)
                        last = None

                    elif ennemi_5.get_overflew():
                        ennemi_5.change_to_select()
                        last_enns_selected = ennemi_5.reset_condition(last_enns_selected)
                        last = None

                    elif ennemi_6.get_overflew():
                        ennemi_6.change_to_select()
                        last_enns_selected = ennemi_6.reset_condition(last_enns_selected)
                        last = None

                    elif ennemi_7.get_overflew():
                        ennemi_7.change_to_select()
                        last_enns_selected = ennemi_7.reset_condition(last_enns_selected)
                        last = None

                elif event.type == pygame.KEYDOWN:
#                   si la touche escape (échap) ou la touche return (entré) est pressée, on retourne au menu principal
                    if event.key == pygame.K_ESCAPE \
                            or event.key == pygame.K_RETURN:
#                       on arrête la boucle interne pour arrêter la fonction et ainsi retourner au menu principal
                        play = False

#   on enregistre les sélection dans les fichiers textes
    fonctions_utiles.update_skins([i.get_image_bank(3) for i in last_enns_selected])
    fonctions_utiles.update_skin_save(last_av_selected.get_image_bank(3))

#   Assertion
    assert type(run) == bool

    return run
# =============================================================================

if __name__ == '__main__':
    pygame.init()
    pygame.display.set_caption("for Earth")
    format_screen = (920, 900)
    screen = pygame.display.set_mode(format_screen)

    run = store(screen)

    print(run)

    pygame.quit()
