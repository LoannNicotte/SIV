# -*- coding: utf-8 -*-
# le \ permet de continuer la ligne précédente à la ligne suivante

# =============================================================================
# importations:

import pygame
# =============================================================================
# classe pour l'avion

class Avion(pygame.sprite.Sprite):

#   ===========================================================================
#   constructeur de la classe

    def __init__(self, jeu) -> None:
        """constructeur de la class Avion
        ----
        pre:
            - jeu est une instance de jeu
        post:
            - None
        """
        # assert type(jeu) == Jeu, "jeu n'est pas une instance de Jeu"
        super().__init__()
#       point de vie de l'avion
        self.vie = 100
#       point de vie maximum
        self.max_vie = 100
#       dégats de l'avion
        self.degats = 5
#       velocité de l'avion vitesse de déplacement en px/image
        self.vitesse = 9
#       armure de l'avion
        self.armure = 0
#       probabilité en float de mettre un coup critique
        self.critique = .05
#       groupe de sprite des projectiles de l'avion
        self.all_projectile = pygame.sprite.Group()
#       objet jeu global, donné en paramêtre: utilisé plus tard
        self.jeu = jeu
#       apparence de l'avion récupérée dans le jeu global et redimensionnée
        self.image = pygame.transform.scale(self.get_jeu().get_image_avion(),
                                            (70, 100)
                                            )
#       on recupère le rectangle de l'image
        self.rect = self.image.get_rect()
#       on détermine l'abcisse et l'ordonnée de base de l'avion
        self.rect.x = 330
        self.rect.y = 720
#       on définie les valeurs de l'abscisse et l'ordonnné maximum de l'avion
        self.x_max = self.rect.x + self.rect.width
        self.y_max = self.rect.y + self.rect.height
        return
#   ===========================================================================

#   ===========================================================================
#   getteurs, accesseurs

    def get_vie(self)->int:
        """getteur, accesseur, méthode qui renvoie la vie de l'avion
        ----
        pre:
            - None
        post:
            - None
        """
        return self.vie

    def get_max_vie(self)->int:
        """getteur, accesseur, méthode qui renvoie la vie maximum que peut\
        avoir l'avion
        ----
        pre:
            - None
        post:
            - None
        """
        return self.max_vie

    def get_damage(self)->int:
        """getteur, accesseur, méthode qui renvoie le nombre de dégats\
        qu'inflige l'avion
        ----
        pre:
            - None
        post:
            - None
        """
        return self.degats

    def get_vitesse(self)->int:
        """getteur, accesseur, méthode qui renvoie la vitesse de l'avion en\
        px/image
        ----
        pre:
            - None
        post:
            - None
        """
        return self.vitesse

    def get_armure(self)->int:
        """getteur, accesseur, méthode qui renvoie les points d'armures de\
        l'avion
        ----
        pre:
            - None
        post:
            - None
        """
        return self.armure

    def get_critique(self)->float:
        """getteur, accesseur, méthode qui renvoie la probabilité qu'une\
        attaque de l'avion soit critique
        ----
        pre:
            - None
        post:
            - None
        """
        return self.critique

    def get_all_projectile(self)->list:
        """getteur, accesseur, méthode qui renvoie le groupe de sprite des\
        projectiles de l'avion
        ----
        pre:
            - None
        post:
            - None
        """
        return self.all_projectile

    def get_jeu(self):
        """getteur, accesseur, méthode qui renvoie l'objet jeu globale
        ----
        pre:
            - None
        post:
            - None
        """
        return self.jeu

    def get_image(self)->pygame.Surface:
        """getteur, accesseur, méthode qui renvoie l'objet jeu globale
        ----
        pre:
            - None
        post:
            - None
        """
        return self.image

    def get_rect(self)->pygame.Rect:
        """getteur, accesseur, méthode qui renvoie l'objet du rectangle de\
        l'image
        ----
        pre:
            - None
        post:
            - None
        """
        return self.rect

    def get_rect_height(self) -> int:
        """getteur qui retourne la hauteur de l'image
        ----
        pre:
            - None
        post:
            - self.rect.height est un int > 0
        """

        #       Assertions
        assert type(self.get_rect().height) == int, "l'attribut height de l'attribut rect n'est pas un int"
        assert self.get_rect().height > 0, "la hateur de l'image est inférieure à 0"

        return self.get_rect().height

    def get_rect_width(self)->int:
        """getteur qui retourne la largeur de l'image
        ----
        pre:
            - None
        post:
            - self.rect.width est un int > 0
        """

#       Assertions
        assert type(self.get_rect().width) == int, "l'attribut width de l'attribut rect n'est pas un int"
        assert self.get_rect().width > 0, "la largeur de l'image est inférieur à 0"

        return self.get_rect().width

    def get_rect_x(self)->int:
        """getteur, accesseur, méthode qui renvoie l'abscisse du rectangle de\
        l'image
        ----
        pre:
            - None
        post:
            - None
        """
        return self.get_rect().x

    def get_rect_y(self)->int:
        """getteur, accesseur, méthode qui renvoie l'ordonnée du rectangle de\
        l'image
        ----
        pre:
            - None
        post:
            - None
        """
        return self.get_rect().y

    def get_x_max(self)->int:
        """getteur, accesseur, méthode qui renvoie l'abscisse maximum de\
        l'avion
        ----
        pre:
            - None
        post:
            - None
        """
        return self.x_max

    def get_y_max(self)->int:
        """getteur, accesseur, méthode qui renvoie l'ordonnée maximum de\
        l'avion
        ----
        pre:
            - None
        post:
            - None
        """
        return self.y_max
#   =============================================================================

#   =============================================================================
    # méthodes qui effectue les effets sonores de notre jeu

    def play_hit_sound(self)->pygame.mixer.Sound:
        self.get_jeu().hit_Sound.play()
        return

    def play_shoot_sound(self)->pygame.mixer.Sound:
        self.get_jeu().shoot_Sound.play()
        return

    def play_upgrades_sound(self)->pygame.mixer.Sound:
        self.get_jeu().upgrade_Sound.play()
        return
#   =============================================================================

#   ===========================================================================
#   méthode de déplacements de l'avion:

    def move_up(self)->None:
# et que le déplacement est possible:, c'est à dire que l'avion ne sort pas de l'écran de jeu
        if self.get_rect_y() - self.vitesse > 0:
            self.rect.y -= self.vitesse
            self.y_max = self.get_rect_y() + self.get_rect_height()
        return

    def move_left(self)->None:
#       Si le déplacement est possible:
#       l'avion ne sort pas de l'écran de jeu
        if self.get_rect_x() - self.vitesse > 0:
            self.rect.x -= self.vitesse
            self.x_max = self.get_rect_x() + self.get_rect_width()
        return

    def move_down(self)->None:
#       et que le déplacement est possible
#       l'avion ne sort pas de l'écran de jeu
        if self.get_y_max() + self.get_vitesse() < self.get_jeu().get_format_screen()[1] - 85:
            self.rect.y += self.get_vitesse()
            self.y_max = self.get_rect_y() + self.get_rect_height()
        return

    def move_right(self)->None:
        """méthode qui déplace l'avion sur la droite de x px tel que x =\
        vitesse de l'avion définie dans les attributs accès par la méthode\
        get_vitesse()
        ----
        pre:
            - None
        post:
            - None
        """
#       si l'avion ne sort pas de l'écran de jeu: si la nouvelle valeur de
#       x_max sort de l'écran de jeu 720px ou longueur - 220px
        if self.get_x_max() + self.get_vitesse() < 720:
            self.rect.x += self.vitesse
            self.x_max = self.rect.x + self.rect.width
        return
#   ===========================================================================

#   ===========================================================================
#   lancement d'un projectile:

    def launch_projectile(self)->None:
        """"""
#       importation
        import projectile

#       Assertions


#       instance de la class projectile
        self.get_all_projectile().add(projectile.Projectile(self))
        self.play_shoot_sound()
        return
#   ===========================================================================

#   ===========================================================================
#   méthode qui retire des pv

    def take_damage(self, damage: int)->None:
        """méthode qui retire des pv
        ----
        pre:
            - None
        post:
            - None
        """
#       dégat réel avec l'absorbance de l'armure
        real_damage = damage - self.armure
        if real_damage > 0:
            self.vie -= real_damage
            self.play_hit_sound()
        return
#   ===========================================================================

#   ===========================================================================
#   méthode qui ajoute des pv

    def regen(self, heal: int)-> None:
        """méthode qui ajoute des pv"""
        self.vie += heal
        if self.vie > self.max_vie:
            self.vie -= self.vie - self.max_vie
        return
#   ===========================================================================

#   ===========================================================================
#     méthode qui met la vie de l'avion au nobre qu'on lui indique

    def set_vie(self, new_value)->None:
        """méthode qui ajoute des pv"""
        self.vie = new_value
        return
#   ===========================================================================

#   ===========================================================================
#     upgrades

    def upgrade_max_vie(self, upgrade_value: int)->None:
        self.max_vie += upgrade_value
        self.play_upgrades_sound()
        return

    def upgrade_damage(self, upgrade_value: int)->None:
        self.degats += upgrade_value
        self.play_upgrades_sound()
        return

    def upgrade_armor(self, upgrade_value: int)->None:
        self.armure += upgrade_value
        self.play_upgrades_sound()
        return

    def upgrade_crit(self, upgrade_value: int)->None:
        self.critique += upgrade_value
        self.play_upgrades_sound()
        return

    def draw_image_border(self, target_surface: pygame.Surface) -> None:
        """fonction qui affichage la zone de collisions de l'avion, elle est\
        exclusivement réservé aux développeurs pour s'aider dans leur code surtout\
        au niveau de la gestion des entités
        ----
        pre:
            - target_surface est une surface pygame
        post:
            - None
        """

        #   Assertions
        assert type(target_surface) == pygame.Surface, "target_surface n'est pas une surface pygame"

        #   on récupère en paramètre la surface sur laquelle on affichera la hitbox et jeu,
        #   la classe qui contient les tout les informations du jeu dont celle de l'avion

        #   on dessine 4 lignes qui tracent les lignes de collisions de l'avion
        #   ligne Nord
        pygame.draw.line(
            #       la surface sur laquelle on trace le trait
            target_surface,
            #       la couleur du trait
            (255, 255, 255),
            #       les coordonnées du point de départ
            (self.get_rect_x(), self.get_rect_y()),
            #       les coordonnées du points d'arriver
            (self.get_x_max(), self.get_rect_y())
        )

        #   ligne Ouest même procédé
        pygame.draw.line(
            target_surface,
            (255, 255, 255),
            (self.get_rect_x(), self.get_rect_y()),
            (self.get_rect_x(), self.get_y_max())
        )

        #   ligne Est
        pygame.draw.line(
            target_surface,
            (255, 255, 255),
            (self.get_x_max(), self.get_rect_y()),
            (self.get_x_max(), self.get_y_max())
        )

        #   ligne Sud
        pygame.draw.line(
            target_surface,
            (255, 255, 255),
            (self.get_rect_x(), self.get_y_max()),
            (self.get_x_max(), self.get_y_max())
        )

        #   fin de la procédure
        return
#   ===========================================================================
# ===========================================================================
