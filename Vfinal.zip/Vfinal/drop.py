# -*- coding: utf-8 -*-
# le \ permet de continuer la ligne précédente à la ligne suivante

# =============================================================================
# importations:

import pygame
# =============================================================================

class Drop(pygame.sprite.Sprite):

    #constructeur de la class
    def __init__(self, ennemi)->None:
        super().__init__()
        self.velocity = 6
        self.ennemi = ennemi
        self.image = pygame.image.load('assets/drop/drop.png')
        self.image = pygame.transform.scale(self.image, (20, 20))
        self.rect = self.image.get_rect()
        self.rect.x = ennemi.rect.x + ennemi.rect.width//2 - self.rect.width//2
        self.rect.y = ennemi.rect.y + 12
        self.x_max = self.rect.x + self.rect.width
        self.y_max = self.rect.y + self.rect.height
        return

    def get_rect(self) -> object:
        """getteur sui retourne le rectangle de l'ennemi
        ----
        pre:
            - None
        post:
            - self.rect est un rectangle pygame
        """
        #       Assertion
        assert type(self.rect) == pygame.Rect, "l'attribut rect n'est pas un un objet"

        return self.rect

    def get_rect_x(self) -> int:
        """getteur qui retourne l'abscisse de l'ennemi
        ----
        pre:
            - None
        post:
            - self.get_rect().x est un int
        """

        #       Assertion
        assert type(self.get_rect().x) == int, "l'attribut rect.x n'est pas un int"

        return self.get_rect().x

    def get_rect_y(self) -> int:
        """getteur qui retourne l'ordonnée de l'ennemi
        ----
        pre:
            - None
        post:
            - self.get_rect().y est un int
        """

        #       Assertion
        assert type(self.get_rect().y) == int, "l'attribut rect.y n'est pas un int"

        return self.get_rect().y

    def get_velocity(self) -> int:
        """getteur qui retourne la vitesse de déplacement du sprite
        ----
        pre:
            - None
        post:
            - self.velocity est un int
        """
#       Assertion
        assert isinstance(self.velocity, int), "self.velocity must be a int, not {}".format(type(self.velocity))

        return self.velocity

    def get_x_max(self) -> int:
        """getteur que retourne l'abcisse maximale de l'image
        pre:
            - None
        post:
            - self.x_max est un int
        """
        #       Assertion
        assert type(self.x_max) == int, "l'attribut x_max n'est pas un int"

        return self.x_max

    def get_y_max(self) -> int:
        """getteur qui retourne la valeur de l'ordonnée maximale de l'image
        pre:
            - None
        post:
            - self.y_max est un int
        """

        #       Assertion
        assert type(self.y_max) == int, "l'attribut y_max n'est pas un int"

        return self.y_max

    #   retire le drop
    def remove(self, group):
        group.remove(self)
        return

#   déplace le drop
    def move(self, group_de_drop: pygame.sprite.Group):
        new_hauteur_min = self.get_rect_y() + self.get_velocity()
        self.rect.y = new_hauteur_min
        self.y_max = new_hauteur_min + self.rect.height
        # verifier si le drop n'est plus sur l'ecran
        if self.rect.y > 800:
            # suprimer le drop (hors ecran)
            self.remove(group_de_drop)
        return
