# -*- coding: utf-8 -*-
# le \ permet de continuer la ligne précédente à la ligne suivante

# =============================================================================
# importations

import random as rdm

import pygame
import time
import avion
import ennemis
import fonctions_utiles
# =============================================================================

# =============================================================================
# classe du jeu

class Jeu:
    """class qui stock les infos du jeu et différentes fonctions"""
    #   ===========================================================================
    #   constructeur du jeu
    def __init__(
            self,
            songs: tuple = [None]*6,
            format_screen: tuple = (920, 900),
            image_avion: pygame.Surface = pygame.image.load(fonctions_utiles.get_last_skin_avion()),
            skins_enn: list = fonctions_utiles.get_skins_enn()
    ) -> None:
        """constructeur, procédure qui détermine les attributs de la class Jeu\
        ----
        pre:
            - format_screen est un tuple de 2 int
            - image_avion est une instance de pygame.Surface
            - skins_enn est une list de 3 str
        post:
            - None
        """

        #       Assertions
        assert type(format_screen) == tuple, "l'argument 0 n'est pas un tuple"
        assert len(format_screen) == 2, "l'argument 0 n'a pas la longueur demander (2)"
        for i, j in enumerate(format_screen):
            assert type(j) == int, "l'élément {} de l'argument 0 n'est pas un int".format(i)
            assert j >= 0, "l'élément {} de l'argument 0 n'est pas supérieur ou égal à 0".format(i)

        assert type(image_avion) == pygame.Surface, "l'argument 1 n'est pas une surface pygame"

        assert type(skins_enn) == list, "l'argument 2 n'est pas une list"
        assert len(skins_enn) <= 3, "l'argument 2 est trop long"
        for i, j in enumerate(skins_enn):
            assert type(j) == str, "l'élement {} de l'élément 2 n'est pas un str".format(i)

        self.image_avion = image_avion
        self.all_drops = pygame.sprite.Group()
        self.all_ennemis = pygame.sprite.Group()
        self.all_projectiles_ennemis = pygame.sprite.Group()
        #       nombre de point d'armure
        self.armure = 0
        #       l'avion
        self.avion = avion.Avion(self)
        #       seconde de la dernière vague
        self.der_vague = 0
        #       format de l'écran
        self.format_screen = format_screen
        #       somme argent
        self.gold = 0
        #       somme d'argent totale (pour le résumé de la partie)
        self.gold_tot = 0
        #       nombre élimination
        self.kill = 0
        #       niveau actuel de difficulté du jeu
        self.level = 1
        #       liste qui stock tout les textes d'afficlages des coups critiques
        self.list_of_crit = []
        #       niveau d'amélioration de la vie maximum
        self.nv_coeur = 1
        #       niveau d'amélioration du taux de coup critique
        self.nv_critique = 1
        #       niveau d'amélioration des dégats de l'avion
        self.nv_degats = 1
        #       nombre de potions
        self.potion = 0
        #       score actuel
        self.score = 0
        #       liste des chemins des apparences des ennemis sélectionné
        self.skins_enn = skins_enn
        #       seconde où le jeu à été lancé
        self.temps_debut_programme = time.time()
        #       temps de jeu en seconde de l'utilisateur sur la partie courante
        self.tps_de_jeu = 0
        #       temps de jeu en minute de l'utilisateur sur la partie courante
        self.tps_minutes = 0
        self.tps_minutes_memoire = self.get_tps_minutes()
        #       temps de jeu en seconde de l'utilisateur sur la partie courante
        self.tps_sec = 0
        self.tps_sec_memoire = self.get_tps_sec()
        #       meilleur score
        self.HIGHT_SCORE = fonctions_utiles.get_hight_score()
        #       image de l'amélioration de l'armure
        self.ARMURE_IMAGE = pygame.transform.scale(
            pygame.image.load("assets/upgrade/armure.png"),
            (100, 100)
        )
        #       image de l'amélioration de la vie maximum
        self.COEUR_IMAGE = pygame.transform.scale(
            pygame.image.load("assets/upgrade/coeur.png"),
            (100, 100)
        )
        #       image de l'amélioration du taux de coup critique
        self.CRITIQUE_IMAGE = pygame.transform.scale(
            pygame.image.load("assets/upgrade/critique.png"),
            (100, 100)
        )
        #       image de l'amélioration des dégats
        self.EPEE_IMAGE = pygame.transform.scale(
            pygame.image.load("assets/upgrade/epe.png"),
            (100, 100)
        )
        #       image des pièces d'or à dorite du nombre
        self.GOLD_IMAGE = pygame.transform.scale(
            pygame.image.load("assets/upgrade/or.png"),
            (30, 30)
        )
        #       image des potions de vie
        self.POTION_VIE_IMAGE = pygame.transform.scale(
            pygame.image.load("assets/upgrade/potion_vie.png"),
            (100, 100)
        )
        #       image du flou gris utiliser dans la boutique
        self.FLOU = pygame.transform.scale(
            pygame.image.load("assets/shop/flou.png"),
            (self.get_format_screen()[0] // 2, 50)
        )
        #       image d'item bloqué (cadenas)
        self.NULL = pygame.image.load('assets/shop/avion/cadenas.png')
        #       jeu.pressed est un dictionnaire qui a pour clé les valeurs associées à
        #       la pression d'une touche et en valeurs un booléen ou None si pas la cle
        #       n'a pas encore été définie, les valeurs possibles sont donc:
        #       - True: touche préssée;
        #       - False: touche relachée
        #       - None: pas encore définie
        self.pressed = {}

        #   le dictionnaire stock toutes les images des items et autres boutons du jeu
        #   toutes les images en fonction du statut (normal ou rien de special, survolé,
        #   sélectionné et le chemin de l'apparences en jeu normal
        #        - l'élement 0 correspond à ni survolé ni selctionné;
        #        - l'élement 1 correspond à survolé;
        #        - l'élement 2 correspond à selectionné (optionnel);
        #        - l'élement 3 correspond à l'apparence de l'objet en jeu (optionnel),
        #           cet item est utilisé que pour l'enregistrement des séléction
        #           par le programme principal (plus bas, à la fin de la procédure store)
        self.banque_images = {
            "close button": (
                #               image du bouton lorsqu'il n'est pas survolé
                pygame.image.load('assets/general/fermer_no.png'),
                #               image du bouton lorsqu'il est survolé
                pygame.image.load("assets/general/fermer_o.png")
            ),
            "return to main Menu": (
                pygame.image.load('assets/general/RtMM_no.png'),
                pygame.image.load('assets/general/RtMM_o.png')
            ),
            "boutique": (
                pygame.image.load("assets/m_m/2_boutique_no.png"),
                pygame.image.load("assets/m_m/2_boutique_o.png")
            ),
            "jeu": (
                pygame.image.load("assets/m_m/1_jeu_no.png"),
                pygame.image.load("assets/m_m/1_jeu_o.png")
            ),
            "pdc": (
                pygame.image.load("assets/m_m/3_pdc_no.png"),
                pygame.image.load("assets/m_m/3_pdc_o.png")
            ),
            "avion 1": (
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion1/avion1_A.png"),
                    (185, 140)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion1/avion1_B.png"),
                    (185, 140)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion1/avion1_C.png"),
                    (185, 140)
                ),
                'assets/avion/avion1.png'
            ),
            "avion 2": (
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion2/avion2_A.png"),
                    (140, 140)
                ),

                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion2/avion2_B.png"),
                    (140, 140)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion2/avion2_C.png"),
                    (140, 140)
                ),
                'assets/avion/avion2.png'
            ),
            "avion 3": (
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion3/avion3_A.png"),
                    (140, 140)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion3/avion3_B.png"),
                    (140, 140)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion3/avion3_C.png"),
                    (140, 140)
                ),
                'assets/avion/avion3.png'
            ),
            "avion 4": (
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion4/avion4_A.png"),
                    (235, 295)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion4/avion4_B.png"),
                    (235, 295)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion4/avion4_C.png"),
                    (235, 295)
                ),
                'assets/avion/avion4.png'
            ),
            "avion 5": (
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion5/avion5_A.png"),
                    (140, 140)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion5/avion5_B.png"),
                    (140, 140)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion5/avion5_C.png"),
                    (140, 140)
                ),
                'assets/avion/avion5.png'
            ),
            "avion 6": (
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion6/avion6_A.png"),
                    (140, 140)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion6/avion6_B.png"),
                    (140, 140)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion6/avion6_C.png"),
                    (140, 140)
                ),
                'assets/avion/avion6.png'
            ),
            "avion 7": (
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion7/avion7_A.png"),
                    (235, 295)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion7/avion7_B.png"),
                    (235, 295)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion7/avion7_C.png"),
                    (235, 295)
                ),
                'assets/avion/avion7.png'
            ),
            "avion 8": (
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion8/avion8_A.png"),
                    (235, 295)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion8/avion8_B.png"),
                    (235, 295)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/avion/avion8/avion8_C.png"),
                    (235, 295)
                ),
                'assets/avion/avion8.png'
            ),
            "ennemi 1": (
                pygame.transform.scale(
                    pygame.image.load("assets/shop/ennemi/ennemi1/alien1A.png"),
                    (185, 140)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/ennemi/ennemi1/alien1B.png"),
                    (185, 140)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/ennemi/ennemi1/alien1C.png"),
                    (185, 140)
                ),

                'assets/alien/alien1.png'
            ),
            "ennemi 2": (
                pygame.transform.scale(
                    pygame.image.load("assets/shop/ennemi/ennemi2/alien2A.png"),
                    (140, 140)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/ennemi/ennemi2/alien2B.png"),
                    (140, 140)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/ennemi/ennemi2/alien2C.png"),
                    (140, 140)
                ),
                'assets/alien/alien2.png'
            ),
            "ennemi 3": (
                pygame.transform.scale(
                    pygame.image.load("assets/shop/ennemi/ennemi3/alien3A.png"),
                    (360, 295)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/ennemi/ennemi3/alien3B.png"),
                    (360, 295)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/ennemi/ennemi3/alien3C.png"),
                    (360, 295)
                ),
                'assets/alien/alien3.png'
            ),
            "ennemi 4": (
                pygame.transform.scale(
                    pygame.image.load("assets/shop/ennemi/ennemi4/alien4A.png"),
                    (350, 295)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/ennemi/ennemi4/alien4B.png"),
                    (350, 295)
                ),
                pygame.transform.scale(
                    pygame.image.load(
                        "assets/shop/ennemi/ennemi4/alien4C.png"),
                    (350, 295)
                ),
                'assets/alien/alien4.png'
            ),
            "ennemi 5": (
                pygame.transform.scale(
                    pygame.image.load("assets/shop/ennemi/ennemi5/alien5A.png"),
                    (140, 140)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/ennemi/ennemi5/alien5B.png"),
                    (140, 140)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/ennemi/ennemi5/alien5C.png"),
                    (140, 140)
                ),
                'assets/alien/alien5.png'
            ),
            "ennemi 6": (
                pygame.transform.scale(
                    pygame.image.load("assets/shop/ennemi/ennemi6/alien6A.png"),
                    (140, 140)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/ennemi/ennemi6/alien6B.png"),
                    (140, 140)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/ennemi/ennemi6/alien6C.png"),
                    (140, 140)
                ),
                'assets/alien/alien6.png'
            ),
            "ennemi 7": (
                pygame.transform.scale(
                    pygame.image.load("assets/shop/ennemi/ennemi7/alien7A.png"),
                    (140, 140)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/ennemi/ennemi7/alien7B.png"),
                    (140, 140)
                ),
                pygame.transform.scale(
                    pygame.image.load("assets/shop/ennemi/ennemi7/alien7C.png"),
                    (140, 140)
                ),
                'assets/alien/alien7.png'
            )
        }
#       effets sonores
        self.hit_Sound = songs[0]
        self.shoot_Sound = songs[1]
        self.upgrade_Sound = songs[2]
        self.shoot_ennemi_song = songs[3]
        self.avion_death_song = songs[4]
#       fin du contructeur
        return

    #   ===========================================================================

    #   ===========================================================================
    #   getteurs ou accesseurs des attributs: méthodes (fonctions d'une classe)
    #   qui retournent les valeurs des attributs de la class Jeu

    def get_all_drops(self) -> pygame.sprite.Group:
        """getteur, accesseur, méthode qui renvoie le groupe de sprite pygame\
        des bonus lachés à la mort des ennemis
        ----
        pre:
            - None
        post:
            - self.all_drops est un groupe de sprite pygame
        """
        #       Assertions
        assert type(self.all_drops) == pygame.sprite.Group, "l'attribut all_drops n'est pas un groupe de sprite"

        return self.all_drops

    def get_all_ennemis(self) -> pygame.sprite.Group:
        """getteur, accesseur, méthode qui renvoie le groupe de sprite pygame\
        des ennemis
        ----
        pre:
            - None
        post:
            - all_ennemis est un groupe de sprite pygame
        """
        #       Assertion
        assert type(self.all_ennemis) == pygame.sprite.Group, "l'attribut all_ennemis n'est pas un groupe de sprite"

        return self.all_ennemis

    def get_all_projectiles_ennemis(self) -> pygame.sprite.Group:
        """getteur, accesseur, méthode qui renvoie le groupe de sprite pygame\
        des projectiles ennemis
        ----
        pre:
            - None
        post:
            - all_ennemis est un groupe de sprite pygame
        """

        #       Assertion
        assert type(self.all_ennemis) == pygame.sprite.Group, \
            "l'attribut all_projectiles_ennemis n'est pas un groupe de sprite"

        return self.all_projectiles_ennemis

    def get_armure(self) -> int:
        """getteur, accesseur, méthode qui renvoie le niveau d'armure du joueur
        ----
        pre:
            - None
        post:
            - self.armure est un int sépérieur ou égal à 0
        """

        #       Assertions
        assert type(self.armure) == int, "l'attribut armure n'est pas un int"
        assert self.armure >= 0, "l'attribut armure n'est pas supérieur ou égal à 0"

        return self.armure

    def get_avion(self) -> avion.Avion:
        """getteur, accesseur, méthode qui renvoie l'objet avion
        ----
        pre:
            - None
        post:
            - self.avion est une instance d'Avion
        """

        #       Assertion
        assert type(self.avion) == avion.Avion, "avion n'est pas une instance d'Avion"

        return self.avion

    def get_der_vague(self) -> int:
        """getteur, accesseur, méthode qui renvoie la sec de la dernière vague\
        d'ennemis
        ----
        pre:
            - None
        post:
            - self.der_vague est un int supéprieur ou égal à 0
        """

        #       Assertions
        assert type(self.der_vague) == int, "l'attribut der_vaugue n'est pas un int"
        assert self.der_vague >= 0, "l'attribut der_vague n'est pas supérieur ou égal à 0"

        return self.der_vague

    def get_format_screen(self) -> tuple:
        """getteur, accesseur, méthode qui renvoie le tuple du format de\
        l'écran
        ----
        pre:
            - None
        post:
            - self.format_screen est un tuple de 2 int supérieur ou égal à 0
        """

        #       Assertions
        assert type(self.format_screen) == tuple, "l'attribut format_screen n'est pas un tuple"
        for i, j in enumerate(self.format_screen):
            assert type(j) == int, "l'élément {} du tuple n'est pas un int".format(i)
            assert j >= 0, "l'élément {} de l'argument 0 n'est pas supérieur ou égal à 0".format(i)

        return self.format_screen

    def get_flou(self) -> pygame.Surface:
        """méthode qui retourne le fond gris dans la boutique
        pre:
            - None
        post:
            - self.FLOU est une surface pygame
        """

        #       Assertion
        assert type(self.FLOU) == pygame.Surface, "l'attribut FLOU n'est pas une surface pygame"

        return self.FLOU

    def get_gold(self) -> int:
        """getteur, accesseur, méthode qui renvoie l'argent du joueur
        ----
        pre:
            - None
        post:
            - self.gold est un int supérieur ou égal à 0
        """

        #       Assertions
        assert type(self.gold) == int, "l'attribut gold n'est pas un int"
        assert self.gold >= 0, "l'attribut gold n'est pas supérieur ou égal à 0"

        return self.gold

    def get_gold_tot(self) -> int:
        """getteur, accesseur, méthode qui renvoie l'argent du joueur total\
        sans les dépenses
        ----
        pre:
            - None
        post:
            - self.gold_tot est un int supérieur ou égal à 0
        """

        #       Assertions
        assert type(self.gold_tot) == int, "l'attribut gold_tot n'est pas un int"
        assert self.gold_tot >= 0, "l'attribut gold_tot n'est pas supérieur ou égal à 0"

        return self.gold_tot

    def get_hight_score(self) -> int:
        """getteur, acesseur qui retourne le meilleur score actuel à battre
        pre:
            - None
        post:
            - self.HIGHT_SCORE est un int
        """
        #       Assertion
        assert type(self.HIGHT_SCORE) == int, "HIGHT_SCORE n'est pas un int"

        return self.HIGHT_SCORE

    def get_image_avion(self) -> pygame.Surface:
        """getteur, accesseur, méthode qui retourne l'objet pygame qui\
        correspond à l'image de l'avion
        ----
        pre:
            - None
        post:
            - self.image_avion est une surface pygame
        """

        #       Assertion
        assert type(self.image_avion) == pygame.Surface, "l'attribut image_avion n'est pas une surface pygame"

        return self.image_avion

    def get_kill(self) -> int:
        """getteur, accesseur, méthode qui renvoie le nombre d'élimination du\
        joueur
        ----
        pre:
            - None
        post:
            - self.kill est un int supérieur ou égal à 0
        """

        #       Assertions
        assert type(self.kill) == int, "l'attribut kill n'est pas un int"
        assert self.kill >= 0, "l'attribut kill n'est pas supérieur ou égal à 0"

        return self.kill

    def get_level(self) -> int:
        """getteur, accesseur, méthode qui renvoie le niveau de difficulté du\
        jeu
        ----
        pre:
            - None
        post:
            - self.level est un int supérieur ou égal à 1
        """
        #       Assertions
        assert type(self.level) == int, "l'attribut level n'est pas un int"
        assert self.level >= 1, "l'attribut level n'est pas supérieur ou égal à 1"

        return self.level

    def get_list_of_crit(self) -> list:
        """getteur, accesseur, méthode qui renvoie la liste des textes à\
        afficher pour les coups critiques
        ----
        pre:
            - None
        post:
            - list_of_crit est un list de tuple dont l'élément 0 est \
            un str, le 1 est un int, le 2 est un tuple de 3 int et\
             le 3 est un tuple de 2 int
        """

        #       Assertions
        assert type(self.list_of_crit) == list, "l'attribut list_of_crit n'est pas une list"
        for l, k in enumerate(self.list_of_crit):
            assert type(k[0]) == str, \
                "l'élément 0 de l'élément {} de l'attribut list_of_crit n'est pas un str".format(l)
            assert type(k[1]) == int, "l'élément 1 de l'élément {} de l'attribut list_of_crit n'est pas un int".format(
                l)
            assert type(
                k[2]) == tuple, "l'élément 2 de l'élément {} de l'attribut list_of_crit n'est pas un tuple".format(l)
            assert len(k[2]) == 3, \
                "l'élément 2 de l'élément {} de l'attribut list_of_crit ne contient pas le bon nombre d'élément".format(
                    l)
            for i, j in enumerate(k[2]):
                assert type(j) == int, \
                    "l'élément {} de l'élément 2 de l'élément {} de l'attribut list_of_crit n'est pas un int".format(i,
                                                                                                                     l)
            assert type(
                k[3]) == tuple, "l'élément 3 de l'élément {} de l'attribut list_of_crit n'est pas un tuple".format(l)
            assert len(k[3]) == 2, "l'élément 3 de l'élément {} ne contient pas le bon nombre d'élément".format(l)
            for i, j in enumerate(k[3]):
                assert type(
                    j) == int, "l'élément {} de l'élément 3 de l'élément {} de l'attribut list_of_crit n'est pas un int".format(
                    i, l)

        return self.list_of_crit

    def get_image_cadena(self) -> pygame.Surface:
        """méthode qui retourne l'image de cadena
        pre:
            - None
        post:
            - self.NULL est une surface pygame
        """

        #       Assertion
        assert type(self.NULL) == pygame.Surface

        return self.NULL

    def get_nv_coeur(self) -> int:
        """getteur, accesseur, méthode qui renvoie le niveau des points de vie\
        maximum du joueur
        ----
        pre:
            - None
        post:
            - self.nv_coeur est un int supérieur ou égal 0
        """

        #       Assertions
        assert type(self.nv_coeur) == int, "l'attribut nv_coeur n'est pas un int"
        assert self.nv_coeur

        return self.nv_coeur

    def get_nv_critique(self) -> int:
        """getteur, accesseur, méthode qui renvoie l'argent du joueur
        ----
        pre:
            - None
        post:
            - self.nv_critique est un int supérieur ou égal à 0
        """

        #       Assertions
        assert type(self.nv_critique) == int, "l'attribut nv_critique n'est pas un int"
        assert self.nv_critique >= 0, "l'attebut nv_critique n'est pas supérieur ou égal à 0"

        return self.nv_critique

    def get_nv_degats(self) -> int:
        """getteur, accesseur, méthode qui renvoie le niveau des dégats du\
        joueur
        ----
        pre:
            - None
        post:
            - self.nv_degats est un int supérieur ou égal à 0
        """

        #       Assertions
        assert type(self.nv_degats) == int, "l'attribut nv_degats n'est pas un int"
        assert self.nv_degats >= 0, "l'attribut nv_degats n'est pas supérieur ou égal à 0"

        return self.nv_degats

    def get_potion(self) -> int:
        """getteur, accesseur, méthode qui renvoie le nombre de potion qu'a le\
        joueur
        ----
        pre:
            - None
        post:
            - self.potion est un int >= 0
        """

        # Assertions
        assert type(self.potion) == int, "l'attribut potion n'est pas un int"
        assert self.potion >= 0, "l'attribut potion n'est pas supérieur ou égal à 0"

        return self.potion

    def get_score(self) -> int:
        """getteur, accesseur, méthode qui renvoie l'argent du joueur
        ----
        pre:
            - None
        post:
            - self.score est un int >= 0
        """

        # Assertions
        assert type(self.score) == int, "l'attribut score n'est pas un int"
        assert self.score >= 0, "l'attribut score n'est pas supérieur ou égal à 0"

        return self.score

    def get_skins_enn(self) -> list:
        """getteur, accesseur, méthode qui renvoie les apparences choisies par\
        le joueur
        ----
        pre:
            - None
        post:
            - self.skins_enn est une list de 3 str
        """

        #       Assertions
        assert type(self.skins_enn) == list, "l'attribut skins_enn n'est pas une list"
        assert len(self.skins_enn) == 3, "l'attribut skins_enn n'est pas une list de 3 éléments"
        for i, j in enumerate(self.skins_enn):
            assert type(j) == str, "l'élément {} n'est pas un str"

        return self.skins_enn

    def get_temps_debut_programme(self) -> float:
        """getteur, accesseur, méthode qui renvoie le temps à l'instant t en\
        secondes
        ----
        pre:
            - None
        post:
            - self.temps_debut_programme est un float supérieur ou égal à 0
        """

        #       Assertions
        assert type(self.temps_debut_programme) == float, "l'attribut temps_debut_programme n'est pas un int"
        assert self.temps_debut_programme >= 0, "l'attribut temps_debut_programme n'est pas supérieur ou égal à 0"

        return self.temps_debut_programme

    def get_tps_de_jeu(self) -> int:
        """getteur, accesseur, méthode qui renvoie le temps de jeu en seconde
        ----
        pre:
            - None
        post:
            - self.tps_de_jeu est un int >= 0
        """

        #       Assertions
        assert type(self.tps_de_jeu) == int, "l'attribut tps_de_jeu n'est pas un int"
        assert self.tps_de_jeu >= 0, "l'attrbut tps_de_jeu n'est pas supérieur ou égal à 0"

        return self.tps_de_jeu

    def get_tps_minutes(self) -> int:
        """getteur, accesseur, méthode qui renvoie le nombre de minutes de\
        temps de jeu
        ----
        pre:
            - None
        post:
            - self.tps_minutes est un int >= 0
        """

        #       Assertions
        assert type(self.tps_minutes) == int, "l'attribut tps_minutes n'est pas un int"
        assert self.tps_minutes >= 0, "l'attribut tps_minutes n'est pas supérieur ou égal à 0"

        return self.tps_minutes

    def get_tps_minutes_memoire(self) -> int:
        """getteur, accesseur, méthode qui renvoie le nombre de minutes de\
        temps de jeu avant la boucle qui passe
        ----
        pre:
            - None
        post:
            - self.tps_minutes_memoire est un int >= 0
        """

        #       Assertions
        assert type(self.tps_minutes_memoire) == int, "l'attribut tps_minutes_memoire n'est pas un int"
        assert self.tps_minutes_memoire >= 0, "l'attribut tps_minutes_memoire n'est pas supérieur ou égal à 0"

        return self.tps_minutes_memoire

    def get_tps_sec(self) -> int:
        """getteur, accesseur, méthode qui renvoie le temps de jeu en seconde\
        sans les minutes
        ----
        pre:
            - None
        post:
            - self.tps_sec est un int >= 0
        """

        #       Assertions
        assert type(self.tps_sec) == int, "l'attribut tps_sec n'est pas un int"
        assert self.tps_sec >= 0, "l'attribut tps_sec n'est pas supérieur ou égal à 0"

        return self.tps_sec

    def get_tps_sec_memoire(self) -> int:
        """getteur, accesseur, méthode qui renvoie le temps de jeu en seconde\
        sans les minutes avant la boucle qui passe
        ----
        pre:
            - None
        post:
            - self.tps_sec est un int >= 0
        """

        #       Assertions
        assert type(self.tps_sec_memoire) == int, "l'attribut tps_sec_memoire n'est pas un int"
        assert self.tps_sec_memoire >= 0, "l'attribut tps_sec_memoire n'est pas supérieur ou égal à 0"

        return self.tps_sec_memoire

    def get_armure_image(self) -> pygame.Surface:
        """getteur, accesseur, méthode qui renvoie l'image de l'amélioration\
        de l'armure
        ----
        pre:
            - None
        post:
            - self.ARMURE_IMAGE est une surface pygame
        """

        #       Assertion
        assert type(self.ARMURE_IMAGE) == pygame.Surface, "l'attribut ARMURE_IMAGE n'est pas une surface pygame"

        return self.ARMURE_IMAGE

    def get_coeur_image(self):
        """getteur, accesseur, méthode qui renvoie l'image de l'amélioration\
        de la vie maximum
        ----
        pre:
            - None
        post:
            - self.COEUR_IMAGE est une surface pygame
        """

        #       Assertion
        assert type(self.COEUR_IMAGE) == pygame.Surface, "l'attribut COEUR_IMAGE n'est pas une surface pygame"

        return self.COEUR_IMAGE

    def get_critique_image(self) -> pygame.Surface:
        """getteur, accesseur, méthode qui renvoie l'image de la potion de vie
        ----
        pre:
            - None
        post:
            - self.CRITIQUE_IMAGE est une surface pygame
        """

        #       Assertion
        assert type(self.CRITIQUE_IMAGE) == pygame.Surface, "l'attribut CRITIQUE_IMAGE n'est pas une surface pygame"

        return self.CRITIQUE_IMAGE

    def get_epee_image(self) -> pygame.Surface:
        """getteur, accesseur, méthode qui renvoie l'image de l'amélioration\
        de dégat
        ----
        pre:
            - None
        post:
            - self.EPEE_IMAGE est une surface pygame
        """

        #       Assertion
        assert type(self.EPEE_IMAGE) == pygame.Surface, "l'attribut EPEE_IMAGE n'est pas une surface pygame"

        return self.EPEE_IMAGE

    def get_gold_image(self) -> pygame.Surface:
        """getteur qui retourne l'image des pièces d'or
        pre:
            - None
        post:
            - self.GOLD_IMAGE est une surface pygame
        """

        #       Assertion
        assert type(self.GOLD_IMAGE) == pygame.Surface, "l'attribut GOLD_IMAGE n'est pas une surface pygame"

        return self.GOLD_IMAGE

    def get_potion_de_vie_image(self) -> pygame.Surface:
        """getteur, accesseur, méthode qui renvoie l'image de la potion de vie
        ----
        pre:
            - None
        post:
            - self.POTION_VIE_IMAGE est une surface pygame
        """

        #       Assertion
        assert type(self.POTION_VIE_IMAGE) == pygame.Surface, "l'attribut POTION_VIE_IMAGE n'est pas une surface pygame"

        return self.POTION_VIE_IMAGE

    def get_pressed(self) -> dict:
        """getteur, accesseur, méthode qui renvoie le dictionnaire des\
        touches préssées
        ----
        pre:
            - None
        post:
            - self.pressed est un dict
        """

        #       Assertion
        assert type(self.pressed) == dict, "l'attribut pressed n'est pas un dict"

        return self.pressed

    def get_images(self) -> dict:
        """getteur, accesseur, méthode qui renvoie le dictionnaire des\
        différentes apparences de notre application
        ----
        pre:
            - None
        post:
            - self.banque_images est un dict avec des clé en str et comme valeurs des tuple dont l'élément 0 et 1 sont \
            des surfaces pygames, s'il y a 3 éléments le troisième est une surface pygame et s'il y a un quatrième \
            élément c'est un str
        """

        #       Assertions
        assert isinstance(self.banque_images, dict), "self.banques is not a dict"
        for j in self.banque_images.keys():
            assert type(j) == str, "la cle: {} n'est un str".format(j)
            assert type(self.banque_images.get(j)) == tuple, "la valeur de la clé \"{}\" n'est pas un tuple"
            assert 2 <= len(self.banque_images.get(j)) <= 4, "le tuple de la clé \"{}\" n'a pas une bonne longueur"
            for i in range(2):
                assert type(self.banque_images.get(j)[i]) == pygame.Surface, \
                    "l'élément {} du tuple de la clé \"{}\" n'est pas une surface pygame"
            if len(self.banque_images.get(j)) >= 3:
                assert type(self.banque_images.get(j)[2]) == pygame.Surface, \
                    "l'élément 2 du tuple de la clé \"{}\" n'est pas une surface pygame"
                if len(self.banque_images.get(j)) == 4:
                    assert type(self.banque_images.get(j)[3]) == str, \
                        "l'élé^ment 3 du tuple de la clé \"{}\" n'est pas un str"

        return self.banque_images

    #   ===========================================================================

    def play_avion_death_song(self)->None:
        self.avion_death_song.play()
        return

    #   ===========================================================================
    #   setteurs ou mutatateurs: méthodes qui permettent de modifier ou changer des
    #   valeurs elles impactent donc les attributs de la classe

    def spawn_ennemies(self) -> None:
        """méthode qui fait apparaitre des ennemis en ajoutant des instances\
        d'ennenmis dans le groupe de sprite self.all_ennemis
        ----
        pre:
            - None
        post:
            - None
        ----
        On choisie dans la liste des abscisses d'ennemis possibles un nombre
        aléatoire d'abscisses différentes
        rdm.randint(4, 8) choisie un nombre aléatoire entre 4 et 8 inclus
        ce nombre correspond au nombre d'ennemis qu'il y aura sur la vague crée

        [i for i in range(20, 680, 80)] est une liste par compréhension qui
        contient toutes les abscisses possibles des ennemis (la première est
        20px et la dernière est 680px), il mesure 40px de largeur et on ajoute
        40px comme espace minimum entre ennemis, donc les abscisses possibles
        sont sélectionnables de 20 à 680 (px) et le pas est 80

        rdm.sample choisie dans la liste le nombre d'ennemi choisie au dessus
        fois une abscisse différentes, 2 ennemis de la même vague n'auront
        jamais la même abscisse
        pour chaque abcisse décidé aléatoirement
        """
        for x in rdm.sample([i for i in range(20, 680, 80)], rdm.randint(4, 8)):
            #           on ajoute un instance de la class Ennemi, en spécifiant l'abscisse
            #           en plus de self, au groupe all_ennemis
            self.get_all_ennemis().add(ennemis.Ennemi(self, x))
        return

    def change_key_conditon(self, key_pygame: int, new_condition: bool):
        """méthode qui fait varier le dictionnaire mémoire des touches préssées en modifiant la valeur enregistrée \
        pour la nouvelle donnée en argument au niveau de la clé indiquée en argument
        ----
        pre:
            - key_pygame est un int >= 0
            - new_condition est un bool
        post:
            - None
        """

        #       Assertions
        assert type(key_pygame) == int, "l'argument 0 n'est pas un int, il doit en être un"
        assert type(new_condition) == bool, "l'argument 0 n'est pas un int, il doit en être un"

        self.pressed[key_pygame] = new_condition
        return

    def achat(self, prix: int) -> None:
        """méthode qui soustrait un prix à la bourse du joueuer
        ----
        pre:
            - prix est un int >= 0
        post:
            - None
        """

        #       Assertions
        assert type(prix) == int, "prix n'est pas un int"
        assert prix >= 0, "prix négatif"

        self.gold -= prix
        return

    def use_heal_potion(self) -> None:
        """méthode qui utilse une potion de vie
        ----
        pre:
            - self.get_potion() > 0
        post:
            -None
        """

        #       Assertion
        assert self.get_potion() > 0, "régénération impossible"
        #       utilisation de la potion: régénération de 20 pv et une
        #       potion en moins
        self.potion -= 1
        #       méthode de régénération de l'avion
        self.get_avion().regen(20)

        return

    # On définie la procédure en cas de mort d'un ennemi
    def ennemis_death(self, ennemi: ennemis.Ennemi) -> None:
        """procédure qui fait les action à faire en cas de décés d'un\
        ennemi
        ----
        pre:
            - ennemi est une instance de Ennemi
        post:
            - None
        """

        #       Assertions
        assert type(ennemi) == ennemis.Ennemi, "ennemi n'est pas une instance de Ennemi"

        #       On tue l'ennemie par la procédure dont il est doté
        ennemi.remove(self.get_all_ennemis(), self.get_all_drops())

        #       On ajoute une élimination
        self.kill += 1

        #       On ajoute 10 au score
        self.score += 10

        #       On ajoute 5 l'argent et à l'argent total perçu
        self.gold += 5
        self.gold_tot += 5

        #       fin de la procédure
        return

    def print_upgrade(self, screen: pygame.Surface) -> None:
        """procédure qui affiche les images des améliorations sur l'écran à\
        droite
        ----
        pre:
            - screen est une surface pygame
        post:
            - None
        """

        #       Assertion
        assert type(screen) == pygame.Surface, "screen n'est pas une surface pygame"

        #       affichage image de la potion proposée à l'achat
        screen.blit(self.get_potion_de_vie_image(), (770, 20))

        #       affichage de l'image de l'epee, symbole de l'améliorations des dégats
        screen.blit(self.get_epee_image(), (770, 190))

        #       affichage de l'image du symbole de l'amélioration des coups critiques
        screen.blit(self.get_critique_image(), (770, 380))

        #       affichage de l'image du symbole de l'amélioration de l'armure
        screen.blit(self.get_armure_image(), (770, 550))

        #       affichage de l'image du symbole de l'amélioration de la vie maximum
        screen.blit(self.get_coeur_image(), (770, 720))

        #       afficher de l'icône or
        screen.blit(self.get_gold_image(), (780, 860))

        #       fin de la procédure
        return

    def return_main_menu(self, screen: pygame.Surface, background: pygame.Surface, run: bool) -> False:
        """fonction qui retourne un tuple dont le premier élément est False pour arréter la boucle de game et le \
        deuxième élément est run récupéré en paramêtre et peut-être modifié donc on le renvoie. Cette fonction affiche \
        aussi le menu la mort de l'avion ou abandon ou partie perdue
        ----
        pre:
            - screen est un surface pygame
            - background est un surface pygame
            - run est un bool
        post:
            - run est un bool
        """

        #       Assertions
        assert type(screen) == pygame.Surface, "screen n'est pas un surface pygame"
        assert type(background) == pygame.Surface, "background n'est pas un surface pygame"
        assert type(run) == bool, "run n'est pas un bool"

#       =============================================================================
#       initialisation des variables

        #       On démarre la boucle de cette page
        running = True

        #       On initialise le tuple de la couleur de l'affichage pour passer
        color = (0, 0, 0)

        #       on initialise des variables utiles
        screen_width: int = screen.get_width()
        screen_height: int = screen.get_height()

#       on charge l'image avec les textes généraux centrés
        back_ret_to_MM: pygame.Surface = pygame.image.load('assets/m_m/return_to_MM.png')
#       =============================================================================

#        on joue le son de la mort de l'avion
        self.play_avion_death_song()

        #       boucle de l'affichage
        while running:
            #           On affiche le fond étoilé
            screen.blit(background, (0, 0))

            #           On affiche l'image avec les texte généraux centrés
            screen.blit(back_ret_to_MM, (0, 0))

            #           statistiques de la partie:
            #           nombre de kill
            fonctions_utiles.add_txt(screen, self.kill_t, 30, (255, 255, 255), ((screen_width // 3) * 2,
                                                                                (screen_height // 2) + 200))
            #           temps de jeu
            fonctions_utiles.add_txt(screen, self.chrono, 30, (255, 255, 255), (10,
                                                                                (screen_height // 2) + 230))
            #           meilleur score
            fonctions_utiles.add_txt(screen, self.max_score, 30, (255, 255, 255), (10,
                                                                                   (screen_width // 2) + 200))
            #           score de cette partie
            fonctions_utiles.add_txt(screen, self.score_t, 30, (255, 255, 255),
                                     (10, (screen_height // 2) + 170))
            #           somme d'argent
            fonctions_utiles.add_txt(screen, "gold : " + self.gold_t, 30, (255, 255, 255),
                                     (screen_width // 3, (screen_height // 2) + 170))
            #           niveau des ennemis
            fonctions_utiles.add_txt(
                screen,
                self.level_t,
                30,
                (
                    255,
                    255,
                    255
                ),
                (
                    (screen_width // 3) * 2,
                    (screen_height // 2) + 170
                )
            )
            #           somme d'argent totale gagné
            fonctions_utiles.add_txt(
                screen,
                "or totals perçu : {} PO".format(self.get_gold_tot()),
                30,
                (
                    255,
                    255,
                    255
                ),
                (
                    screen_width // 3,
                    (screen_height // 2) + 200
                )
            )

            #           affichage de l'aide pour passer
            fonctions_utiles.add_txt(
                screen,
                "appuyer sur n'importe quel touche pour passer",
                40,
                color,
                (
                    150,
                    screen_height - 150
                )
            )

#           changement de couleur de la dernière ligne
            if color[0] == 0:
#               True veut dire que la teneur de rouge augmente et la teneur de
#               bleu diminue
                action = True
            elif color[0] == 254:
#               False veut dire que la teneur de rouge diminue et la teneur de
#               bleu augmente
                action = False
# On change la couleur en fonction des teneurs en rouge et bleu
            if action:
                color = ((color[0] + 1) % 255, 0, (color[2] - 1) % 255)
            else:
                color = ((color[0] - 1) % 255, 0, (color[2] + 1) % 255)

            #           ===================================================================
            #           update screen/mise à jour de l'affichage:

            fonctions_utiles.update_screen()
            #           ===================================================================

            #           le module pygame enregistre tout les événements qui se passe sur la
            #           fenêtre: touche préssé, mouvement de la souris, click de souris,
            #           croix rouge de fermeture, ...
            for event in pygame.event.get():

                #               si l'utilisateur click sur la croix rouge
                if event.type == pygame.QUIT:
                    #                   On quitte l'application
                    #                   On récupère la vairable qui gère le bouclage l'application général
                    running = False
                    run = False

                #               si l'utilisateur appuye sur une touche
                elif event.type == pygame.KEYDOWN:
                    #                   On arrète cette boucle est on retourne donc au menu
                    #                   principal car cette procédure se finira et game aussi
                    running = False

                elif event.type == pygame.MOUSEBUTTONDOWN:
                    running = False

        #       mise à jour du meilleur score et enregistrement de celui-ci:
        fonctions_utiles.update_hight_score(self.get_score(), self.get_hight_score())

        #       On arrête la boucle du jeu en retournant False car False sera affecté à
        #       la variable play responsable du bouclage de game et on renvoie le nouveau
        #       run si celui-ci n'a pas varié il vaut toujours True mais si il à été
        #       modifié dans la procédure il vaudra False

        #       Assertion
        assert type(run) == bool, "run n'est pas un bool"

        #       fin de la fonction
        return False, run

    def gestion_ennemi_projectiles_avion_drops(self, screen: pygame.Surface, background: pygame.Surface,
                                               play: bool, run: bool) -> tuple:
        """fonction qui retourne play et run dans un tuple car ils peut-être changé par la fonction. \
        Cette fonction effectue toute la gestion du jeu au niveau de la\
        modification des ennemis en fonction du niveau, au niveau des\
        collisions et des déplacements automatiques des missiles et objets\
        déposés
        ----
        pre:
            - screen est une surface pygame
            - background est une surface pygame
            - play est un bool
            - run est un bool
        post:
            - play est un bool
        """

        #   importations
        import projectile as proj
        import drop as drp

        #   Assertions
        assert type(screen) == pygame.Surface, "screen n'est pas une surface pygame"
        assert type(background) == pygame.Surface, "background n'est pas une surface pygame"
        assert type(play) == bool, "play n'est pas un bool"
        assert type(run) == bool, "run n'est pas un bool"

        #   variables utiles
        screen_height = screen.get_height()

        #   tous les projectile de l'avion se déplace
        #   pour chaque projectile de l'avion
        for projectile in self.get_avion().get_all_projectile():
            projectile: proj.Projectile
            #       On le déplace selon sa méthode (voir dans projectile.py)
            projectile.move(self.get_avion().get_all_projectile())

        #   pour chaque ennemi
        for ennemi in self.get_all_ennemis():
            ennemi: ennemis.Ennemi

            #       mise à jour des dégats et de sa vie
            #       On verifie que l'ennemi n'a pas déja été modifié
            if not ennemi.get_mutation():
                ennemi.update_ennemi_level(self.get_level())

            #       si l'ennemi a traversé entièrement l'écran de jeu
            if ennemi.get_y_max() >= screen_height - 50:
                #           le joueur a perdu
                play = self.return_main_menu()

            #       affichage de la barre de vie de l'ennemi
            #       le rectangle de fond blanc grâce à procédure pygame.draw.rect()
            #       qui prend en argument la surface, la couleur sous forme
            #       (Red, Green, Blue) allant de 0 à 255 pour chaque valeur, et une
            #       liste qui en 0 l'abscisse du point en haut à gauche du rectangle,
            #       en 1 l'ordonnée du même point, en 2 la longueur du rectangle en px
            #       et en 3 l'épaisseur du rectangle en px
            pygame.draw.rect(
                screen,
                (255, 255, 255),
                [
                    ennemi.get_rect_x() + 3,
                    ennemi.get_rect_y() - 10,
                    ennemi.get_rect().width - 3,
                    6
                ]
            )

            #       le rectangle vert, grace à la même procédure,
            #       qui correspond à la vie que l'ennemi a
            #       donc la surface est toujours screen, la couleur est du vert,
            #       et la liste qui determine le point en haut à gauche 1 pixel plus
            #       à droite blanc et 1 pixel plus bas que le fond , la longueur est
            #       égale à la vie qu'a l'ennemis x la longueur maximumu de la barre //
            #       vie maximum de l'ennemi
            #       le // premet d'avoir directement un entier puisqu'il s'agit du
            #       quotient
            pygame.draw.rect(screen,
                             (0, 255, 0),
                             [
                                 ennemi.get_rect_x() + 4,
                                 ennemi.get_rect_y() - 9,
                                 (ennemi.get_vie() * 35) // ennemi.get_max_vie(),
                                 4
                             ]
                             )

            #       lancement de projectiles si le random tiré est inférieur à ses
            #       chances de tiré
            if (rdm.random() < ennemi.get_chance_de_tir()):
                ennemi.launch_projectile(self.all_projectiles_ennemis)

            #       deplacement de l'ennemi toute les 2 sec, la première codition
            #       permet de faire ce déplacement qu'une seule fois toutes les 2 sec
            if ((self.get_tps_sec_memoire() != self.get_tps_sec()) and (self.get_tps_sec() % 2 == 0)):
                ennemi.move_down()

            #       pour chaque projectile de l'avion allié
            for projectile in self.get_avion().all_projectile:
                #           On teste la collision entre le projectile allié et  l'ennemi
                #           On vérifie la similitude des axes en x, en y, on aurait pu ne
                #           pas mettre le and mais grâce à python mais dans le cas là nous
                #           avons préféré pour se repérer
                if (
                        #              x: axe gauche ennemi < axe gauche projectile < axe droite ennemi
                        #              ou axe gauche ennemi < axe droite projectile < axe droite ennemi
                        (
                                (
                                        (ennemi.get_rect_x() < projectile.get_rect_x())
                                        and (projectile.get_rect_x() < ennemi.get_x_max())
                                )
                                or
                                (
                                        (ennemi.get_rect_x() < projectile.get_x_max())
                                        and (projectile.get_x_max() < ennemi.get_x_max())
                                )
                        )
                        and
                        #               y: axe haut ennemi < axe haut projectile < axe bas ennemi
                        #               ou axe haut ennemi < axe bas projectile < axe bas ennemi
                        (
                                (
                                        (ennemi.get_rect_y() < projectile.get_rect_y())
                                        and (projectile.get_rect_y() < ennemi.get_y_max())
                                )
                                or
                                (
                                        (ennemi.get_rect_y() < projectile.get_y_max())
                                        and (projectile.get_y_max() < ennemi.get_y_max())
                                )
                        )
                ):
                    #                   determine s'il y a un coup critique de l'avion
                    if (rdm.random() < self.get_avion().get_critique()):
                        #                       On inflige 2/3 de dégats supplémentaire à l'ennemi
                        ennemi.take_damage(int(self.get_avion().get_damage() * 5 / 3))
                        #                       On ajoute un tuple pour l'affichage dans le jeu
                        self.get_list_of_crit().append(
                            ("crit!",
                             23,
                             (255, 0, 0),
                             (ennemi.get_rect_x() + 3, ennemi.get_rect_y() + 45),
                             self.get_tps_sec()
                             )
                        )
                    #                   porcédure normale
                    else:
                        #                       l'ennemi prend les dégats de l'avion
                        ennemi.take_damage(self.get_avion().get_damage())
                    #                   On retire le missile car il a été utilisé
                    projectile.remove(self.get_avion().get_all_projectile())
                    #                   si l'ennemi est mort
                    if ennemi.get_vie() <= 0:
                        #                       On éxécute la procédure correspondante définie plus
                        #                       haut
                        self.ennemis_death(ennemi)

            #           On teste la collision entre l'ennemi et l'avion
            if (
                    #              x: axe gauche avion < axe gauche ennemi < axe droite avion
                    #              ou axe gauche avion < axe droite ennemi < axe droite avion
                    (
                            (
                                    (self.get_avion().get_rect_x() < ennemi.get_rect_x())
                                    and (ennemi.get_rect_x() < self.get_avion().get_x_max())
                            )
                            or
                            (
                                    (self.get_avion().get_rect_x() < ennemi.get_x_max())
                                    and (ennemi.get_x_max() < self.get_avion().get_x_max())
                            )
                    )
                    and
                    #               y: axe haut avion < axe haut ennemi < axe bas avion
                    #               ou axe haut avion < axe bas ennemi < axe bas avion
                    (
                            (
                                    (self.get_avion().get_rect_y() < ennemi.get_rect_y())
                                    and (ennemi.get_rect_y() < self.get_avion().get_y_max())
                            )
                            or
                            (
                                    (self.get_avion().get_rect_y() < ennemi.get_y_max())
                                    and (ennemi.get_y_max() < self.get_avion().get_y_max())
                            )
                    )
            ):
                #               On inflige les dégats à l'avion
                self.get_avion().take_damage(10)
                #               et à l'ennemi
                ennemi.take_damage(self.get_avion().get_damage())
                #               si l'ennemi meurt car vie <= 0
                if (ennemi.get_vie() <= 0):
                    #                  On éxécute la procédure correspondante définie plus
                    #                  haut
                    self.ennemis_death(ennemi)

        #       On déplace tous les projectile des ennemis
        for projectile in self.get_all_projectiles_ennemis():
            projectile: proj.Projectile_ennemi
            projectile.move(self.get_all_projectiles_ennemis())

            # On teste la collision de chaque missile ennemi avec l'avion
            if (
                    #              x: axe gauche avion < axe gauche projectile < axe droite avion
                    #              ou axe gauche avion < axe droite projectile < axe droite avion
                    (
                            (
                                    (self.get_avion().get_rect_x() < projectile.get_rect_x())
                                    and (projectile.get_rect_x() < self.get_avion().get_x_max())
                            )
                            or
                            (
                                    (self.get_avion().get_rect_x() < projectile.get_x_max())
                                    and (projectile.get_x_max() < self.get_avion().get_x_max())
                            )
                    )
                    and
                    #               y: axe haut avion < axe haut projectile < axe bas avion
                    #               ou axe haut avion < axe bas projectile < axe bas avion
                    (
                            (
                                    (self.get_avion().get_rect_y() < projectile.get_rect_y())
                                    and (projectile.get_rect_y() < self.get_avion().get_y_max())
                            )
                            or
                            (
                                    (self.get_avion().get_rect_y() < projectile.get_y_max())
                                    and (projectile.get_y_max() < self.get_avion().get_y_max())
                            )
                    )
            ):
                #               On inflige les dégats à l'avion
                self.get_avion().take_damage(ennemi.get_damage())
                #               On retire le missile ennemis
                projectile.remove(self.get_all_projectiles_ennemis())

        #        On déplace tous les bonus de décés des ennemis
        for drop in self.get_all_drops():
            drop: drp.Drop
            drop.move(self.get_all_drops())
            #           On teste la collision entre le bonus et l'avion
            if (
                    #              x: axe gauche avion < axe gauche bonus < axe droite avion
                    #              ou axe gauche avion < axe droite bonus < axe droite avion
                    (
                            (
                                    (self.get_avion().get_rect_x() < drop.get_rect_x())
                                    and (drop.get_rect_x() < self.get_avion().get_x_max())
                            )
                            or
                            (
                                    (self.get_avion().get_rect_x() < drop.get_x_max())
                                    and (drop.get_x_max() < self.get_avion().get_x_max())
                            )
                    )
                    and
                    #               y: axe haut avion < axe haut bonus < axe bas avion
                    #               ou axe haut avion < axe bas bonus < axe bas avion
                    (
                            (
                                    (self.get_avion().get_rect_y() < drop.get_rect_y())
                                    and (drop.get_rect_y() < self.get_avion().get_y_max())
                            )
                            or
                            (
                                    (self.get_avion().get_rect_y() < drop.get_y_max())
                                    and (drop.get_y_max() < self.get_avion().get_y_max())
                            )
                    )
            ):
                #               procédure qui éxécute le bonus
                #               méthode de régénération de l'avion
                self.get_avion().regen(3)
                #               On retire le bonus
                drop.remove(self.get_all_drops())

        assert type(play) == bool, "play n'est pas un bool"
        assert type(run) == bool, "play n'est pas un bool"
        #       fin de la procédure
        return play, run

    def add_tps_de_pause(self, tps: float)->None:
        assert isinstance(tps, float), "argument 0 must be a float, not {}".format(type(tps))
        self.temps_debut_programme += tps
        return
#   ===========================================================================
# =============================================================================
