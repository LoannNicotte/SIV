﻿# -*- coding: utf-8 -*-
# le \ permet de continuer la ligne précédente à la ligne suivante
# =============================================================================
# importations:

import pygame
# =============================================================================

class Bouton_selectionnable:
    """
    class qui permet de faire un bouton avec plusieurs images en fonctions de son statut
    """

    def __init__(self, name: str, image_bank: tuple) -> None:
        """constructeur de la classe
        ----
        pre:
            - name est un str
            - image_bank est un tuple
        post:
            - None
        """
        assert type(name) == str, "l'argument 0 n'est pas un str"
        assert type(image_bank) == tuple, "l'argument 1 n'est pas un tuple"
        assert 0 < len(image_bank) <= 4, "il n'y a pas le bon nombre d'images fournis en argument 1 dans\
            le tuple"
        assert type(image_bank[0]) == pygame.Surface, "l'élément 0 de l'argument 1 n'est pas une surface pygame"
        assert type(image_bank[1]) == pygame.Surface, "l'élément 1 de l'argument 1 n'est pas une surface pygame"
        if len(image_bank) > 2:
            assert type(image_bank[2]) == pygame.Surface, "l'élément 2 de l'argument 1 n'est pas une surface pygame"
        if len(image_bank) == 4:
            assert type(image_bank[3]) == str, \
                "l'élément 3 de l'argument 1 n'est pas un str"
        super().__init__()
        self.selected = False
        self.overflew = False
        self.image_bank = image_bank
        self.image = self.image_bank[0]
        self.name = name
        return

    def get_selected(self) -> bool:
        """méthode qui retourne  le bouléen qui est le statut de l'objet:\
        séléctionné(True) ou non(False)
        ----
        pre:
            - None
        post:
            - self.selected est un bool
        """
        assert type(self.selected) == bool, "l'attribue sélected n'est pas un bool"
        return self.selected

    def get_overflew(self) -> bool:
        """méthode qui retourne le bouléen qui est le statut de l'objet:\
        séléctionné(True) ou non(False)
        ----
        pre:
            - None
        post:
            - self.selected est un bool
        """
        assert type(self.overflew) == bool, "l'attribue overflew n'est pas un bool"
        return self.overflew

    def get_image(self) -> pygame.Surface:
        """méthode qui retourne l'objet image
        ----
        pre:
            - None
        post:
            - self.image est une surface pygame
        """
        assert type(self.image) == pygame.Surface, "l'attribue image n'est pas une surface pygame"
        return self.image

    def get_image_bank(self, k: int = None) -> tuple:
        """méthode qui retourne soit un élément spécifique du tuple dans le cas ou k est spécifié, \
	    soit le tuple entier
        ----
        pre:
            - k est None ou un entier compris entre 0 et le rang maximum du tuple
        post:
            - None
        """
        assert type(k) == int or k is None, "l'argument 1 n'est pas du type int or None"
        if type(k) == int:
            assert 0 <= k <= len(self.image_bank) - 1, "l'argument 1 n'est pas trouvable"
            return_value = self.image_bank[k]
            assert type(return_value) == pygame.Surface or type(
                return_value) == str, "la valeur a retourner n'est pas dans un format valable"
        else:
#      	    k est donc None donc on revoie toute les images
            return_value = self.image_bank
            assert type(return_value) == tuple, "la valeur retourner n'est pas un tuple"
        return return_value

    def get_name(self) -> str:
        """méthode qui retourne le nom donné au boutton
        ----
        pre:
            - None
        post:
            - self.name est un str
        """
        assert type(self.name) == str, "l'attribut name n'est pas un str"
        return self.name

    def change_to_norm(self) -> None:
        """méthode qui affecte l'image de quand l'item n'est ni sélectionné ou survolé à l'objet
        ----
        pre:
            - self.get_image_bank(0) est une surface pygame
        post:
            - None
            """
#       on change l'image donc on vérifie que la nouvelle image soit bien une surface pygame
        assert type(self.get_image_bank(0)) == pygame.Surface, "l'attribut image_bank[0] n'est pas une surface pygame"
        self.image = self.get_image_bank(0)
#       on réinitialise le statut du bouton
        self.overflew = False
        self.selected = False
#       fin de la méthode
        return

    def change_to_overflew(self) -> None:
        """méthode qui affecte l'image de quand l'item est survolé à l'objet
        ----
        pre:
            - self.get_image_bank(0) est une surface pygame
        post:
            - None
        """
#       on change l'image donc on vérifie que la nouvelle image soit bien une surface pygame
        assert type(self.get_image_bank(1)) == pygame.Surface, "self.image_bank[1] n'est pas une surface pygame"
        self.image = self.get_image_bank(1)
#       on stock le fait que l'objet est survolé
        self.overflew = True
#       fin de la méthode
        return

    def change_to_select(self: object) -> None:
        """méthode qui affecte l'image de quand l'item est sélectionné à l'objet
        pre:
            - None
        post:
            - None
        """
#       on change l'image du bouton donc on vérifie que la nouvelle image est une surface pygame
        assert type(self.get_image_bank(2)) == pygame.Surface, "self.image_bank[2] n'existe pas ou n'est pas une\
        surface pygame"
        self.image = self.get_image_bank(2)
#       on actualise le statut
        self.selected = True
        self.overflew = False
#       fin de la procédure
        return

    def reset_condition(self,
                        last_items: list = []) -> list:
        """fonction qui réinitialise la plus ancienne des 3 sélections s'il y en a 3, sélectionne le nouveau bouton\
        sélectionné et retourne la nouvelle liste
        ----
        pre :
            - last_items est une list d'instance de Bouton_selectionnable d'au plus 3 éléments
        post:
            - last_items est une list d'instance de Bouton_selectionnable d'au plus 3 éléments
        """

    #       Assertions
        assert type(last_items) == list, "l'argument 1 n'est pas une liste"
        assert len(last_items) <= 3, "l'argument 1 est trop long"
        for i, j in enumerate(last_items):
            assert type(j) == Bouton_selectionnable, \
                "l'élément {} de l'argument 1 n'est pas un Bouton_selectionnable".format(i)

        if len(last_items) == 3:
    #       on réinitialise la sélection la plus ancienne des 3 et la supprime
            last_items[0].change_to_norm()
            del last_items[0]

    #       on sélectionne la nouvelle
        self.change_to_select()

    #       on l'ajoute à la liste des sélections à la fin pour respecter l'ordre chronologique
        last_items.append(self)

    #       Assertions
        assert type(last_items) == list, "last_items n'est pas une list"
        assert len(last_items) <= 3, "last_items comporte trop d'éléments"
        for i, j in enumerate(last_items):
            assert type(j) == Bouton_selectionnable, \
                "l'élément {} de last_items n'est pas un bouton_selectionnable".format(i)

        return last_items
