# -*- coding: utf-8 -*-
# le \ permet de continuer la ligne précédente à la ligne suivante

# =============================================================================
# Importations

import time
import pygame
import fonctions_utiles

from jeu import Jeu
# =============================================================================

# =============================================================================
# code du jeu

def game(screen: pygame.Surface,
        songs: tuple,
        background: pygame.Surface = pygame.transform.scale(pygame.image.load('assets/general/fond.jpg'),(920, 900)),
        run: bool = True,
        format_screen: tuple = (920, 900)
    )->bool:
    """procédure qui est le code du jeu
    ----
    pre:
        - screen est une surface pygame
        - background est une surface pygame
        - run est un bool
        - format_screen est un tuple de 2 int
    post:
        - run est un bool
    """

    #   Assertions
    assert type(screen) == pygame.Surface, "screen n'est pas une surface pygame"
    assert type(background) == pygame.Surface, "background n'est pas une surface pygame"
    assert type(run) == bool, "run n'est pas un bool"
    assert type(format_screen) == tuple, "format_screen n'est pas un tuple"
    for i, j in enumerate(format_screen):
        assert type(j) == int, "l'élément {} de format_screen n'est pas un int".format(i)

#   =============================================================================
#   initialisations des variables

#   on initialise des variables utiles
    screen_height = screen.get_height()

#   boucle du jeu
    play = True
#   on initialise le jeu
    jeu = Jeu(
        songs,
        format_screen,
        pygame.image.load(fonctions_utiles.get_last_skin_avion()),
        fonctions_utiles.get_skins_enn()
    )
#   =============================================================================

#   boucle tant que play sur True
    while play:
#       =======================================================================
#       général:
#       background du jeu
        screen.blit(background, (0, 0))
#       =======================================================================

#       =======================================================================
#       timer:
#       les mémoires prennent la dernière valeur de sec ou min pour cette
#       itération de la boucle
        jeu.tps_minutes_memoire = jeu.get_tps_minutes()
        jeu.tps_sec_memoire = jeu.get_tps_sec()
#       heure actuel - l'heure du lancement du jeu = temps du jeu (en sec)
        jeu.tps_de_jeu = round(time.time() - jeu.get_temps_debut_programme())
#       On met les valeurs de sec et minute à jour
        jeu.tps_sec = jeu.get_tps_de_jeu() % 60
        jeu.tps_minutes = jeu.get_tps_de_jeu() // 60
#       =======================================================================

#       =======================================================================
#       gestion des monstres / avions / projectilies / bonus:

#           régénération de la vie et augmentation de l'argent passive
#           toutes les 10 sec et qu'une seule fois car à l'itération d'après la
#           première condition sera fausse
        if ((jeu.get_tps_sec_memoire() != jeu.get_tps_sec()) and (jeu.get_tps_sec() % 10 == 0)):
#           méthode de régénération de la vie de l'avion
#           On ajoute 2 point de vie à l'avion
            jeu.get_avion().regen(2)
#           augmentation de l'argent et donc du totale d'argent perçu
            jeu.gold += 10
            jeu.gold_tot += 10

#       apparition de monstre : quand il n'y plus ou pas d'ennemi ou toutes
#       les 20 secondes qu'une seule fois
        if (
                (
#            der_vague est la seconde d'apparition de la dernière vague
                        (((jeu.get_tps_sec() - jeu.get_der_vague()) % 20) == 0)
#            une seule fois
                        and (jeu.get_tps_sec() != jeu.tps_sec_memoire)
                )
                or
#           Il n'y a plus d'ennemi
                (
                        len(jeu.all_ennemis) == 0)
        ):
#           méthode de jeu qui fait apparaître des ennemis
            jeu.spawn_ennemies()
#           On enregistre la sec d'apparition de la dernière vague
            jeu.der_vague = jeu.get_tps_sec()

#       deplacements de l'avion

#       si la touche up (fléche haut) ou la touche w en clavier qwerty
#       (z en français) est pressée, on déplace l'avion vers le haut
        if jeu.get_pressed().get(pygame.K_UP) \
                or jeu.get_pressed().get(pygame.K_w):
            jeu.get_avion().move_up()

#       si la touche LEFT(fléche gauche) ou la touche a (q en français)
#       est pressée, on déplace l'avion vers la gauche
        if jeu.get_pressed().get(pygame.K_LEFT) \
                or jeu.get_pressed().get(pygame.K_a):
            jeu.get_avion().move_left()

#       si la touche down (fléche bas) ou la touche s (même touche)
#       est pressée, on déplace l'avion vers le bas
        if jeu.get_pressed().get(pygame.K_DOWN) \
                or jeu.get_pressed().get(pygame.K_s):
            jeu.get_avion().move_down()

#       si la touche fléche haut ou la touche z en clavier français
#       (w en anglais/Américains) et que le déplacement est possible:
#       l'avion ne sort pas de l'écran de jeu
        if jeu.get_pressed().get(pygame.K_RIGHT) \
                or jeu.get_pressed().get(pygame.K_d):
            jeu.get_avion().move_right()

#       procédure définie plus haut qui gére les ennemis, les projectiles,
#       l'avion les bonus
        play, run = jeu.gestion_ennemi_projectiles_avion_drops(screen, background, play, run)

#       affichage de l'avion sur l'ecran
        screen.blit(jeu.get_avion().get_image(), jeu.get_avion().get_rect())

#       affichage des ennemis sur l'ecran
        jeu.get_all_ennemis().draw(screen)

#       afficher les projectiles ennemis sur l'écran
        jeu.get_all_projectiles_ennemis().draw(screen)

#       afficher les projectiles de l'avion allié sur l'écran
        jeu.get_avion().get_all_projectile().draw(screen)

#       afficher les drops de mort des ennemis sur l'écran
        jeu.get_all_drops().draw(screen)

#       affichage de la barre de vie de l'avion sur le même principe que
#       pour les ennemis (voir gestion_ennemi_projectiles_avion_drops)
        pygame.draw.rect(
            screen,
            (255, 255, 255),
            [10, screen.get_height()-75, 700, 16]
        )
        pygame.draw.rect(screen,
                         (0, 200, 0),
                         [12,
                          screen.get_height()-73,
                          (jeu.get_avion().get_vie() * 696) // jeu.get_avion().get_max_vie(),
                          12
                          ]
                         )
#       =======================================================================

#       =======================================================================
#       upgrades:
#       affichage des images des ameliorations
        jeu.print_upgrade(screen)

#       formation des textes textes qui accompagnent les améliorations
#       pour les potions
        jeu.potion_t = "Nb de potion : {}".format(jeu.get_potion())
#       pour les dégats
        jeu.epee_t = "degats : {} / Nv : {}".format(jeu.get_avion().get_damage(), jeu.get_nv_degats())
#       pour l'armure
        jeu.armure_t = "Nv : {}".format(jeu.get_armure())
#       pour les coup critique
        jeu.critique_t = "Critique : {}% / Nv : {}" \
            .format(round(jeu.get_avion().get_critique() * 100), jeu.get_nv_critique())
#       pour l'ajout de vie maximum
        jeu.coeur_t = "Vie max : {} pv / Nv : {}" \
            .format(jeu.get_avion().get_max_vie(), jeu.get_nv_coeur())

#       affichage de ces textes sur l'écran
        fonctions_utiles.add_txt(screen, jeu.potion_t, 22, (255, 255, 255), (765, 130))
        fonctions_utiles.add_txt(screen, jeu.epee_t, 22, (255, 255, 255), (755, 300))
        fonctions_utiles.add_txt(screen, jeu.armure_t, 22, (255, 255, 255), (800, 660))
        fonctions_utiles.add_txt(screen, jeu.critique_t, 22, (255, 255, 255), (755, 500))
        fonctions_utiles.add_txt(screen, jeu.coeur_t, 22, (255, 255, 255), (740, 830))
#       =======================================================================

#       =======================================================================
#       gestion du scoring (gestion et affichage):

#       gestion du score
#       toutes les minutes, On ajoute 100 au score
        if (jeu.get_tps_minutes() != jeu.get_tps_minutes_memoire()):
            jeu.score += 100

#       On affiche les coup critiques donnés au ennemi
        for i in jeu.get_list_of_crit():

            fonctions_utiles.add_txt(screen, i[0], i[1], i[2], i[3])

#           si la seconde a changer
            if i[4] != jeu.get_tps_sec():
                #               On supprime le texte
                del jeu.list_of_crit[jeu.get_list_of_crit().index(i)]

#       gestion du level
        jeu.level = (jeu.get_kill() // 30) + 1

#       crétion des textes du score
        jeu.chrono = ("temps de jeu = {}: {}".format(jeu.get_tps_minutes(), jeu.get_tps_sec()))
        jeu.level_t = "niveau : {}".format(jeu.get_level())
        jeu.score_t = "Score = {}".format(jeu.get_score())
        jeu.max_score = "Meilleur score = {}".format(jeu.get_hight_score())
        jeu.gold_t = "{} PO".format(jeu.get_gold())
        jeu.kill_t = "Kill = {}".format(jeu.get_kill())

#       affichage des information du jeu
#       On trace les séparations en lignes blanches
        pygame.draw.line(screen,
                         (255, 255, 255),
                         (0, screen_height - 50),
                         (720, screen_height - 50)
                         )
        pygame.draw.line(screen,
                         (255, 255, 255),
                         (720, 0),
                         (720, screen_height)
                         )

#       On ajoute les textes
        fonctions_utiles.add_txt(
            screen,
            jeu.chrono,
            30,
            (255, 255, 255),
            (10, screen_height - 35)
        )

        fonctions_utiles.add_txt(
            screen,
            jeu.score_t,
            22,
            (255, 255, 255),
            (550, screen_height - 40)
        )

        fonctions_utiles.add_txt(
            screen,
            jeu.max_score,
            22,
            (255, 255, 255),
            (550, screen_height - 20)
        )

        fonctions_utiles.add_txt(
            screen,
            jeu.kill_t,
            22,
            (255, 255, 255),
            (430, screen_height - 20)
        )

        fonctions_utiles.add_txt(
            screen,
            jeu.level_t,
            22,
            (255, 255, 255),
            (430, screen_height - 40)
        )

        fonctions_utiles.add_txt(
            screen,
            jeu.gold_t,
            22,
            (255, 255, 255),
            (820, 863)
        )
#       =======================================================================

#       =======================================================================
#       pour les développeurs:
#       si la touche 9 (9 en français) est préssée
        if jeu.get_pressed().get(pygame.K_9):
#           si la touche right shift (majuscule droite en français) est préssée
#           en plus, On fait le code de triche de regen maximum de la vie de
#           l'avion
            if jeu.get_pressed().get(pygame.K_RSHIFT):
#               On met la vie de l'avion à sa valeure maximum
                jeu.get_avion().set_vie(jeu.get_avion().get_max_vie())

#           si la touche equals (égale en français) est pressée en plus,
#           réinitialiser le meilleur score (HIGHT_SCORE)
            if jeu.get_pressed().get(pygame.K_EQUALS):
#               appel de la précédure associée
                fonctions_utiles.reset_hight_score()

#           si la touche g (g en français) est préssée, donner de l'argent
            if jeu.get_pressed().get(pygame.K_g):
#               On donne 10000 d'argent
                jeu.gold += 10000
                jeu.gold_tot += 10000

#           si la touche o (o en français) est préssée, tuer l'avion
#           instantannément
            if jeu.get_pressed().get(pygame.K_o):
#               On met la vie de l'avion à 0
                jeu.get_avion().set_vie(0)
#       =======================================================================


        #       si l'avion meurt car pv <= 0
        if (jeu.get_avion().get_vie() <= 0):
            #           procédure du retour vers le menu principale
            play, run = jeu.return_main_menu(
                screen,
                background,
                run
            )

#       =======================================================================
#       update screen/mise à jour de l'affichage:

        fonctions_utiles.update_screen()
#       =======================================================================

#       =======================================================================
#       pour chaque evenement pri en compte par pygame
        for event in pygame.event.get():

#       si le joueur appuye sur la croix rouge en haut à droite de la fenetre
            if event.type == pygame.QUIT:
#               On quitte l'application
#               On récupère la variable qui fait boucler l'application général
                run = False
#               On arrete la boucle interne de cette procédure
                play = False

#           detecter si le click gauche est appuyer
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:

#               On recupère les coordonnées du click sur l'écran
                x, y = event.pos

#               si la souris est dans l'espace de jeu, tirer un projectile:
                if (
#                       x: 0 < x < 720
                        (0 < x < 720)
                        and
#                       y: 0 < y < 850
                        (0 < y < screen.get_height()-50)
                        ):
                    jeu.get_avion().launch_projectile()

#               sinon si la souris est sur l'image de la potion,
#               acheter une potion
                elif (
#                           x: 770 < x < 870
                        (770 < x < 870)
                        and
#                           y: 20 < y < 120
                        (y > 20 and y < 120)
                        and
#                           si On peut acheter une potion, pas plus
#                           que 5 potions et avoir 500 d'argent
                        (jeu.get_potion() < 5 and jeu.get_gold() >= 500)
                        ):
#                   On éffectue l'achat
#                   On ajoute une potion
                    jeu.potion += 1
#                   en échange de son prix
                    jeu.achat(500)

#               si la souris est sur l'épée violette, ameliorer les degats de
#               l'avion
                elif (
#                           x: 770 < x < 870
                        ( 770 < x < 870)
                        and
#                           y: 190 < y < 290
                        (190 < y  and y < 290)
                        and
#                           si on peut acheter cette amélioration, pas plus
#                           que niveau 5 et avoir 3000 d'argent
                        (jeu.get_nv_degats() < 5 and jeu.get_gold() >= 3000)
                        ):
#                   On éffectue l'achat
#                   On augmente le niveau de dégats de l'avion de 10 points de dégats
                    jeu.nv_degats += 1
                    jeu.get_avion().upgrade_damage(10)
#                   en échage de son prix
                    jeu.achat(3000)

#               si la souris est sur l'épée jaune, ameliorer les chances de
#               coup critique de l'avion
                elif (
#                           x: 770 < x < 870
                        (x > 770 and x < 870)
                        and
#                           y: 390 < y < 490
                        (390 < y < 490)
                        and
#                           si on peut acheter cette amélioration, pas plus
#                           que niveau 5 et avoir 2000 d'argent
                        (jeu.get_nv_critique() < 5 and jeu.get_gold() >= 2000)
                        ):
#                   On augmente le pourcentage de critique de l'avion de
#                   5% = 5/100 = 0.05
                    jeu.nv_critique += 1
                    jeu.get_avion().upgrade_crit(.05)
#                   en échage de son prix
                    jeu.achat(2000)

#               ameliorer l'armure de l'avion
                elif (
#                           x: 770 < x < 870
                        (x > 770 and x < 870)
                        and
#                           y: 550 < y < 650
                        (y > 550 and y < 650)
                        and
#                           si on peut acheter cette amélioration, pas plus
#                           que niveau 3 et avoir 5000 d'argent
                        (jeu.get_armure() < 3 and jeu.get_gold() >= 5000)
                        ):
#                   On augmente le niveau de protection de l'avions
                    jeu.armure +=1
                    jeu.get_avion().upgrade_armor(1)
#                   en échage de son prix
                    jeu.achat(5000)


#               si la souris est sur le coeur, ameliorer la vie maximum de
#               l'avion
                elif (
#                           x: 770 < x < 870
                        (770 < x < 870)
                        and
#                           y: 720 < y < 820
                        (720 < y < 820)
                        and
#                           si on peut acheter cette amélioration, pas plus
#                           que niveau 5 et avoir 4000 d'argent
                        (jeu.get_nv_coeur() <= 5 and jeu.get_gold() >= 4000)
                ):
#                   On augmente le niveau de la vie maximum de l'avion
                    jeu.nv_coeur += 1
                    jeu.get_avion().upgrade_max_vie(20)
#                   On augmente aussi son nombre de points de 20
#                   méthode de régénération de l'avion
                    jeu.get_avion().regen(20)
#                   en échage de son prix
                    jeu.achat(4000)

#           detecter si un joueur appuit une touche du clavier
            elif event.type == pygame.KEYDOWN:
#               On actualise le dictionnaire des touches préssées
                jeu.change_key_conditon(event.key, True)

#               si la touche K est préssée et qu'il y a une potion de vie dans
#               l'inventaire et qu'elle est 100% rentable, on utilise une potion de vie
                if event.key == pygame.K_h and jeu.get_potion() > 0 \
                        and jeu.get_avion().get_vie() < jeu.get_avion().get_max_vie() - 20:
                    jeu.use_heal_potion()

#               si la touche space(espace en fraçais) est préssée,
#               On jette un projectile
                elif event.key == pygame.K_SPACE:
#                   appel de la méthode associée qui jette un projectile allié
                    jeu.get_avion().launch_projectile()

#               si la touche escape (échap en français) est préssée,
#               On retourne au menu principal
                elif event.key == pygame.K_ESCAPE:
                    play, run = jeu.return_main_menu(screen, background, run)

                elif event.key == pygame.K_p:
                    play, run, temps_pause = fonctions_utiles.pause(screen, background, run, play)
                    jeu.add_tps_de_pause(temps_pause)


            # mise à jour du dictionaire
            elif event.type == pygame.KEYUP:
                jeu.change_key_conditon(event.key, False)

#       =======================================================================

#   Assertion
    assert type(run) == bool, "run n'est pas un bool"

#   fin de la fonction
    return run
# =============================================================================

if __name__ == '__main__':
    pygame.init()
    pygame.display.set_caption("for Earth")
    format_screen = (920, 900)
    screen = pygame.display.set_mode(format_screen)

    songs = (
        pygame.mixer.Sound('assets/songs/hit_avion.wav'),
        pygame.mixer.Sound('assets/songs/shoot-avion_1.wav'),
        pygame.mixer.Sound('assets/songs/upgrades.wav'),
        pygame.mixer.Sound('assets/songs/shoot_ennemis.wav'),
        pygame.mixer.Sound('assets/songs/mort_avion.wav')
    )

    run = game(screen, songs)
    print(run)

    pygame.quit()
