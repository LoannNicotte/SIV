﻿# -*- coding: utf-8 -*-
# le \ permet de continuer la ligne précédente à la ligne suivante

# =============================================================================
# importations:

import pygame

from jeu import Jeu
# =============================================================================

def main(screen: pygame.Surface,
        songs: tuple,
        format_screen: tuple = (920, 900),
        background = pygame.transform.scale(pygame.image.load("assets/general/fond.jpg"), (920, 900))
    )->None:
    """application, boucle jusqu'à ce qu'on l'arrête
    ----
    pre:
        - screen est une instance de pygame.Surface
        - format_screen est un tuple de 2 int
        - background est est une instance de pygame.Surface
    post:
        - None
    """

#   =============================================================================
#   importations
    import store
    import game_code
    import fonctions_utiles
    import page_des_commandes

    from bouton_selectionnable import Bouton_selectionnable

#   Assertions
    assert isinstance(screen, pygame.Surface), "argument 0 must be a instance of pygame.Surface, not {}".format(type(screen))
    assert isinstance(format_screen, tuple), "argument 1 must be a tuple, not {}".format(type(format_screen))
    for i, j in enumerate(format_screen):
        assert isinstance(j, int), "element {} of argument 1 must be a int, not {}".format(i, type(j))
    assert isinstance(background, pygame.Surface), "argument 2 must be a instance of pygame.Surface, not {}".format(type(background))
#   =============================================================================

#   =============================================================================
#   intialisation des variables

    Jeu = Jeu(songs)
    last_overflew = None

#   On lance le bouclage de l'application
    run = True

#   On charge l'image du fond d'écran du menu principal
    background_main = pygame.transform.scale(
        pygame.image.load("assets/m_m/main_menu.png"),
        format_screen
    )

#   On créer les boutons de la page

    close_button: Bouton_selectionnable = Bouton_selectionnable(
        "close_button",
        jeu.get_images().get("close button")
    )

    boutique: Bouton_selectionnable = Bouton_selectionnable(
        "boutique",
        jeu.get_images().get("boutique")
    )
    bouton_jeu: Bouton_selectionnable = Bouton_selectionnable(
        "jeu",
        jeu.get_images().get("jeu")
    )
    pdc: Bouton_selectionnable = Bouton_selectionnable(
        "page des commandes",
        jeu.get_images().get("pdc")
    )
#   =============================================================================

#   On lance la boucle de l'application
    while run:

#       affichage du fond d'écran étoilée
        screen.blit(background, (0, 0))

#       affichage des textes généraux par dessus
        screen.blit(background_main, (0, 0))

#       On affiche les boutons
        screen.blit(close_button.get_image(), (2, 2))
        screen.blit(bouton_jeu.get_image(), (100, 390))
        screen.blit(boutique.get_image(), (500, 390))
        screen.blit(pdc.get_image(), (100, 480))

#       =======================================================================
#       update screen/mise à jour de l'affichage:

        fonctions_utiles.update_screen()
#       =======================================================================

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
#               On quitte l'application
#               On récupère la variable qui permet le bouclage de l'appliction globale
#               et on l'arrête
                run = False

            elif event.type == pygame.KEYDOWN:
#               ou une lettre ou voir si click dans le rectangle
                if event.key == pygame.K_1:
                    run = game_code.game(screen, songs, background, run, format_screen)

#               ou une lettre ou si click dans le rectangle
                elif event.key == pygame.K_2:
                    run = store.store(screen, background, jeu)

#               ou une lettre ou si click dans le rectangle
                elif event.key == pygame.K_3:
                    run = page_des_commandes.page_des_commandes(screen)

#               si on appuye sur escape(échap)
                elif event.key == pygame.K_ESCAPE:
#                   On quitte l'application
                    run = False

            elif event.type == pygame.MOUSEMOTION:

                x, y = event.pos

                if (
                        (100 < x < 400)
                        and
                        (390 < y < 450)
                        ):
                    bouton_jeu.change_to_overflew()
                    last_overflew: Bouton_selectionnable = bouton_jeu

                elif(
                        (500 < x < 800)
                        and
                        (390 < y < 450)
                        ):
                    boutique.change_to_overflew()
                    last_overflew: Bouton_selectionnable = boutique

                elif(
                        (100 < x < 400)
                        and
                        (480 < y < 540)
                        ):
                    pdc.change_to_overflew()
                    last_overflew: Bouton_selectionnable = pdc

                elif(
                        (2 < x < 235)
                        and
                        (2 < y < 37)
                        ):
                    close_button.change_to_overflew()
                    last_overflew: Bouton_selectionnable = close_button

                elif last_overflew is not None:
                    last_overflew.change_to_norm()

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:

                if close_button.get_overflew():
                    run = False

                elif bouton_jeu.get_overflew():
                    run = game_code.game(screen, songs, background, run, format_screen)
                    bouton_jeu.change_to_norm()

                elif boutique.get_overflew():
                    run = store.store(screen, background, jeu, run)
                    boutique.change_to_norm()

                elif pdc.get_overflew():
                    run = page_des_commandes.page_des_commandes(screen, background, run)
                    pdc.change_to_norm()

    return

# =============================================================================
# programme principal

if __name__ == "__main__":

    # début de l'application:
    pygame.init()

    # paramètres de la fenêtre:
    pygame.display.set_caption("for Earth")
    format_screen = (920, 900)
    screen = pygame.display.set_mode(format_screen)

    # définition du background
    background = pygame.transform.scale(
        pygame.image.load('assets/general/fond.jpg'),
        format_screen
    )
    #       effets sonores
    songs = (
        pygame.mixer.Sound('assets/songs/hit_avion.wav'),
        pygame.mixer.Sound('assets/songs/shoot-avion_1.wav'),
        pygame.mixer.Sound('assets/songs/upgrades.wav'),
        pygame.mixer.Sound('assets/songs/shoot_ennemis.wav'),
        pygame.mixer.Sound('assets/songs/mort_avion.wav')
    )

#   lancement de l'application
    main(screen, songs, format_screen, background)

    # fermeture de l'application
    pygame.quit()
# =============================================================================
