# -*- coding: utf-8 -*-
# le \ permet de continuer la ligne précédente à la ligne suivante

# =============================================================================
# importations:

import pygame
import avion
import ennemis
# =============================================================================

# =============================================================================
# Code des projectiles du joueur

class Projectile(pygame.sprite.Sprite):
    """classe des projectile de l'avion"""
    import avion
    #constructeur de la class
    def __init__(self, avion_object: avion.Avion)->None:
        """constructeur de la classe
        pre:
            - avion_object est une instance de avion.Avion
        post:
            - None
        """
        #       pas d'assertion possible car les impor

        #       Assertion
        assert type(avion_object) == avion.Avion, \
            "l'argument avion_object n'est pas une instance de avion.Avion mais {}".format(type(avion_object))

        super().__init__()
        self.velocity = 12
        self.avion = avion_object
        self.image = pygame.image.load('assets/tir/tir1.png')
        self.rect = self.image.get_rect()
        self.rect.x = avion_object.rect.x + avion_object.rect.width//2 - self.rect.width//2
        self.rect.y = avion_object.rect.y - self.rect.height
        self.x_max = self.rect.x + self.rect.width
        self.y_max = self.rect.y + self.rect.height

#       fin de la procédure
        return

    def get_avion(self)->avion.Avion:
        """getteur qui retourne l'avion
        ----
        pre:
            - None
        post:
            - self.avion est une instance d' avion.Avion
        """

#       Assertion
        assert type(self.avion) == avion.Avion, \
            "l'attribut avion n'est pas une instance de Avion mais {}".format(type(self.avion))

        return self.avion

    def get_image(self)->pygame.Surface:
        """getteur qui retourne l'image du projectile
        ----
        pre:
            - None
        post:
            - self.image est une instance de pygame.Surface
        """

#       Assertion
        assert type(self.image) == pygame.Surface, \
            "l'attribut image n'est pas une instance de pygmae.Surface mais {}".format(type(self.image))

        return self.image

    def get_rect(self)->pygame.Rect:
        """getteur qui retourne le rectangle du projectile
        ----
        pre:
            - None
        post:
            - self.rect est une instance de pygame.Rect
        """

#       Assertion
        assert type(self.rect) == pygame.Rect, \
            "l'attribut rect n'est pas une instance de pygame.Rect mais {}".format(type(self.rect))

        return self.rect

    def get_rect_height(self) -> int:
        """getteur qui retourne la hauteur de l'image
        ----
        pre:
            - None
        post:
            - self.rect.height est un int > 0
        """

#       Assertion
        assert type(self.get_rect().height) == int, \
            "l'attribut height de l'attribut rect n'est pas un int mais {}".format(type(self.rect.height))
        assert self.get_rect().height > 0, \
            "l'attribut height de l'attribut rect n'est pas supérieur à 0, il vaut {}".format(
                self.get_rect().height)

        return self.get_rect().height

    def get_rect_x(self) -> int:
        """getteur qui retuorne l'abcisse minimale de l'image
        pre:
            - None
        post:
            - self.rect.x est un int inférieur à self.x_max
        """

#       Assertions
        assert type(self.rect.x) == int, "l'attribut x de l'attribut rect n'est pas un int"
        assert self.rect.x < self.x_max, "l'attribut self.rect.x est supérieur à self.x_max"

        return self.rect.x

    def get_rect_y(self) -> int:
        """getteur qui retourne l'ordonnée minimale de l'image
        pre:
            - None
        post:
            - self.rect.y est un int inférieur à self.get_y_max()
        """

#       Assertions
        assert type(self.rect.y) == int, "l'attribut y de l'attribut rect n'est pas int"
        assert self.rect.y < self.y_max, "l'attribut self.rect.y est supérieur à self.y_max"

        return self.rect.y

    def get_velocity(self)->int:
        """getteur qui retourne la vitesse de déplacement
        ----
        pre:
            - None
        post:
            - self.velocity est un int > 0
        """

#       Assertion
        assert type(self.velocity) == int, "l'attribut velocity n'est pas un int mais {}".format(type(self.velocity))
        assert self.velocity > 0, "l'attribut velocity n'est pas suérieur à 0, il vaut {}".format(self.velocity)

        return self.velocity

    def get_x_max(self) -> int:
        """getteur qui retourne l'abscisse maximale de l'image
        pre:
            - None
        post:
            - self.x_max est un int supérieur à self.rect.x
        """

#       Assertions
        assert type(self.x_max) == int, "l'attribut x_max n'est pas un int"
        assert self.x_max > self.rect.x, "l'attribut x_max est inférieur à self.rect.x"

        return self.x_max

    def get_y_max(self) -> int:
        """getteur qui retourne l'ordonnée maximale de l'image
        pre:
            - None
        post:
            - self.y_max est un int supérieur à self.rect.y
        """

#       Assertions
        assert type(self.y_max) == int, "l'attribut y_max n'est pas un int"
        assert self.y_max > self.rect.y, "l'attribut y_max est inférieur à self.rect.y"

        return self.y_max

#   retire le projectile
    def remove(self, group: pygame.sprite.Group)->None:
        """méthode qui supprime le projectile
        ----
        pre:
            - group est une instance de pygame.sprite.Group
        post:
            - None
        """
        assert isinstance(group, pygame.sprite.Group), \
                "group must be pygame.sprite.Group, not {}".format(type(group))

        group.remove(self)

#       fin de la procédure
        return

#   déplace le projectile
    def move(self, group_de_proj: pygame.sprite.Group):
        """méthode qui déplace le projectile selon son système de mouvement içi le projectile monte
        ----
        pre:
            - group_de_proj est une onstance de pygame.sprite.Group
        post:
            - None
        """

#       Assertion
        assert isinstance(group_de_proj, pygame.sprite.Group), \
            "argument 0 must be pygame.sprite.Group, not {}".format(type(group_de_proj))

#       déplacement l'objet descent sur l'écran
        self.rect.y -= self.get_velocity()
#       on actualise y_max avec sa nouvelle valeur
        self.y_max = self.get_rect_y() + self.get_rect().height

#       verifier si le projectile n'est plus sur l'ecran
        if self.rect.y < 0:
#           suprimer le projectile (hors ecran)
            self.remove(self.get_avion().get_all_projectile())

#       fin de la procédure
        return
# =============================================================================

# =============================================================================
# code des projectiles ennemis

class Projectile_ennemi(pygame.sprite.Sprite):
    """classe des projectiles ennemis"""

    #constructeur de la class
    def __init__(self, ennemi: ennemis.Ennemi)->None:
        """constructeur de la classe
        pre:
            - ennemi est une instance d'ennemis.Ennemi
        post:
            - None
        """
        super().__init__()
        self.velocity = ennemi.proj_velo
        self.ennemi = ennemi
        self.image = pygame.image.load('assets/tir/tir_ennemi1.png')
        self.image = pygame.transform.scale(self.image, (8, 20))
        self.rect = self.image.get_rect()
        self.rect.x = ennemi.rect.x + ennemi.rect.width//2 - self.rect.width//2
        self.rect.y = ennemi.rect.y + ennemi.rect.height
        self.x_max = self.rect.x + self.rect.width
        self.y_max = self.rect.y + self.rect.height
#       fin de la procédure
        return

    def get_image(self) -> pygame.Surface:
        """getteur qui retourne l'image du projectile
        ----
        pre:
            - None
        post:
            - self.image est une instance de pygame.Surface
        """

        #       Assertion
        assert type(self.image) == pygame.Surface, \
            "l'attribut image n'est pas une instance de pygmae.Surface mais {}".format(type(self.image))

        return self.image

    def get_rect(self) -> pygame.Rect:
        """getteur qui retourne le rectangle du projectile
        ----
        pre:
            - None
        post:
            - self.rect est une instance de pygame.Rect
        """

#       Assertion
        assert type(self.rect) == pygame.Rect, \
            "l'attribut rect n'est pas une instance de pygame.Rect mais {}".format(type(self.rect))

        return self.rect

    def get_rect_height(self)->int:
        """getteur qui retourne la hauteur de l'image
        ----
        pre:
            - None
        post:
            - self.rect.height est un int > 0
        """

#       Assertion
        assert type(self.get_rect().height) == int, \
            "l'attribut height de l'attribut rect n'est pas un int mais {}".format(type(self.rect.height))
        assert self.get_rect().height > 0, \
            "l'attribut height de l'attribut rect n'est pas supérieur à 0, il vaut {}".format(self.get_rect().height)

        return self.get_rect().height

    def get_rect_x(self) -> int:
        """getteur qui retuorne l'abcisse minimale de l'image
        pre:
            - None
        post:
            - self.rect.x est un int inférieur à self.x_max
        """

#       Assertions
        assert type(self.rect.x) == int, "l'attribut x de l'attribut rect n'est pas un int"
        assert self.rect.x < self.x_max, "l'attribut self.rect.x est supérieur à self.x_max"

        return self.rect.x

    def get_rect_y(self) -> int:
        """getteur qui retourne l'ordonnée minimale de l'image
        pre:
            - None
        post:
            - self.rect.y est un int inférieur à self.get_y_max()
        """

#       Assertions
        assert type(self.rect.y) == int, "l'attribut y de l'attribut rect n'est pas int"
        assert self.rect.y < self.y_max, "l'attribut self.rect.y est supérieur à self.y_max"

        return self.rect.y

    def get_velocity(self) -> int:
        """getteur qui retourne la vitesse de déplacement
        ----
        pre:
            - None
        post:
            - self.velocity est un int > 0
        """

#       Assertion
        assert type(self.velocity) == int, "l'attribut velocity n'est pas un int mais {}".format(
            type(self.velocity))
        assert self.velocity > 0, "l'attribut velocity n'est pas suérieur à 0, il vaut {}".format(self.velocity)

        return self.velocity

    def get_x_max(self) -> int:
        """getteur qui retourne l'abscisse maximale de l'image
        pre:
            - None
        post:
            - self.x_max est un int supérieur à self.rect.x
        """

#       Assertions
        assert type(self.x_max) == int, "l'attribut x_max n'est pas un int"
        assert self.x_max > self.rect.x, "l'attribut x_max est inférieur à self.rect.x"

        return self.x_max

    def get_y_max(self) -> int:
        """getteur qui retourne l'ordonnée maximale de l'image
        pre:
            - None
        post:
            - self.y_max est un int supérieur à self.rect.y
        """

#       Assertions
        assert type(self.y_max) == int, "l'attribut y_max n'est pas un int"
        assert self.y_max > self.rect.y, "l'attribut y_max est inférieur à self.rect.y"

        return self.y_max

#   retire le projectile
    def remove(self, group)->None:
        """méthode qui supprime le projectile du groupe qui le stockait
        pre:
            - None
        post:
            - None
        """

        group.remove(self)

#       fin de la procédure
        return

#   déplace le projectile
    def move(self, group_de_proj: pygame.sprite.Group)->None:
        """méthode qui déplace le projectile selon son système de mouvement içi le projectile monte
        ----
        pre:
            - group_de_proj est une instance de pygame.sprite.Group
        post:
            - None
        """

#       Assertion
        assert isinstance(group_de_proj, pygame.sprite.Group), "argument 0 must be a pygame.sprite.Group, not {}".format(type(group_de_proj))

#       on actualise y_max avec sa nouvelle valeur
        self.y_max = self.get_rect_y() + self.get_velocity() +\
                self.get_rect_height()
#       déplacement l'objet descent sur l'écran
        self.rect.y += self.get_velocity()
#       verifier si le projectile n'est plus sur l'ecran
        if self.get_rect_y() > 800:
#           suprimer le projectile (hors ecran)
            self.remove(group_de_proj)

#       fin de la procédure
        return
# =============================================================================
