# -*- coding: utf-8 -*-
# le \ permet de continuer la ligne précédente à la ligne suivante

# =============================================================================
# importations:

import pygame
import random

from drop import Drop
# =============================================================================

class Ennemi(pygame.sprite.Sprite):

    def __init__(self, jeu, x: int)->None:
        super().__init__()
        self.vie = 20
        self.max_vie = 20
        self.degats = 5
        self.vitesse = 6
        self.proj_velo = 3
        self.jeu = jeu
        self.image = pygame.image.load(random.choice(jeu.get_skins_enn()))
        self.image = pygame.transform.scale(self.image, (40,30))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = 15
        self.x_max = self.rect.x + self.rect.width
        self.y_max = self.rect.y + self.rect.height
        self.chance_de_tir = .005
        self.mutation = False
        return

    def get_chance_de_tir(self) -> float:
        """getteur qui retourne le taux de chance que l'ennemi tir un missil
        ----
        pre:
            - None
        post:
            - self.chance_de_tir
        """

#       Assertion
        assert type(self.chance_de_tir) == float, "l'attribut chance de tir n'est pas un float"

        return self.chance_de_tir

    def get_damage(self)->int:
        """getteur, ascesseur, méthode qui retourne les dégats de l'ennnemi
        ----
        pre:
            - None
        post:
            - self.degats est uh int
        """

#       Assertion
        assert type(self.degats) == int, "l'attribut degats n'est pas un int"

        return self.degats

    def get_jeu(self):
        return self.jeu

    def get_max_vie(self) -> int:
        """getteur qui retourne la vie maximum de l'ennemi
        ----
        pre:
            - None
        post:
            - self.max_vie est un int >= 0
        """

#       Assertions
        assert type(self.max_vie) == int, "l'attribut max_vie n'est pas un int"
        assert self.max_vie >= 0, "l'attribut max_vie n'est pas suéprieur ou égal à 0"

        return self.max_vie

    def get_mutation(self) -> bool:
        """getteur qui retourne si la mutation de l'ennemi a été faite
        ----
        pre:
            - None
        post:
            - self.mutation est un bool
        """

#       Assertion
        assert type(self.mutation) == bool, "l'attribut mutation n'est pas un bool"

        return self.mutation

    def get_rect(self) -> object:
        """getteur sui retourne le rectangle de l'ennemi
        ----
        pre:
            - None
        post:
            - self.rect est un rectangle pygame
        """
#       Assertion
        assert type(self.rect) == pygame.Rect, "l'attribut rect n'est pas un un objet"

        return self.rect

    def get_rect_x(self) -> int:
        """getteur qui retourne l'abscisse de l'ennemi
        ----
        pre:
            - None
        post:
            - self.get_rect().x est un int
        """

#       Assertion
        assert type(self.get_rect().x) == int, "l'attribut rect.x n'est pas un int"

        return self.get_rect().x

    def get_rect_y(self) -> int:
        """getteur qui retourne l'ordonnée de l'ennemi
        ----
        pre:
            - None
        post:
            - self.get_rect().y est un int
        """

#       Assertion
        assert type(self.get_rect().y) == int, "l'attribut rect.y n'est pas un int"

        return self.get_rect().y

    def get_vie(self) -> int:
        """getteur qui retourne la vie de l'ennemi
        ----
        pre:
            - None
        post:
            - self.vie est un int
        """

#       Assertion
        assert type(self.vie) == int, "l'attribut vie n'est pas un int, mais {}".format(type(self.vie))

        return self.vie

    def get_x_max(self) -> int:
        """getteur que retourne l'abcisse maximale de l'image
        pre:
            - None
        post:
            - self.x_max est un int
        """
#       Assertion
        assert type(self.x_max) == int, "l'attribut x_max n'est pas un int"

        return self.x_max

    def get_y_max(self) -> int:
        """getteur qui retourne la valeur de l'ordonnée maximale de l'image
        pre:
            - None
        post:
            - self.y_max est un int
        """

#       Assertion
        assert type(self.y_max) == int, "l'attribut y_max n'est pas un int"

        return self.y_max

    def play_shoot_song(self)->None:
        self.get_jeu().shoot_ennemi_song.play()
        return

#   déplacement des ennemis
    def move_down(self)->None:
        self.rect.y += self.vitesse
        self.x_max = self.rect.x + self.rect.width
        self.y_max = self.rect.y + self.rect.height
        return

#   lancement de projectile ennemi
    def launch_projectile(self, group_of_sprite: pygame.sprite.Group):
#       importations
        import projectile

        #        on joue le son du tir des ennemis
        self.play_shoot_song()
        #instance de la class projectile
        group_of_sprite.add(projectile.Projectile_ennemi(self))
        return

#   fonction qui retire des pv
    def take_damage(self, damage: int)->None:
        self.vie -= damage
        return

# fonction qui retire l'ennemi du jeu en cas de mort
    def remove(self, group: pygame.sprite.Group, group_des_drops: pygame.sprite.Group)->None:
        group.remove(self)
        if random.random() < .5:
            group_des_drops.add(Drop(self))
        return

#   fonction qui rajoute des pv:
    def regen(self, heal: int) -> None:
        self.vie += heal
        if self.vie > self.max_vie:
            self.vie -= self.vie - self.max_vie
        return

    def upgrade_max_vie(self, upgrade_value: int)->None:
        self.max_vie += upgrade_value
        self.regen(upgrade_value)
        return

    def upgrade_chance_de_tir(self, upgrade_value: float)->None:
        if (self.chance_de_tir + upgrade_value <= 0.2):
            self.chance_de_tir += upgrade_value
        return

    def upgrade_damage(self, upgrade_value: int)->None:
        if (self.degats + upgrade_value <= 20):
            self.degats += upgrade_value
        return

    def upgrade_projectils_velocity(self, upgrade_value: int)->None:
        if (self.proj_velo + upgrade_value <= 18):
            self.proj_velo += upgrade_value
        else:
            self.proj_velo += 18
        return

    def update_ennemi_level(self, level: int)->None:
        """procédure qui met à jour les ennemis selon le niveau du jeu:\
        les stastistiques des ennemis augmentent
        ----
        pre:
            - jeu est une instance de Jeu
        post:
            - None
        """

#       Assertion
        assert type(level) == int, "level n'est pas un int"

#       On recupère le niveau dans les variables globales
#       calcul de la valeur ajoutée au valeur de base des ennemis
#       équation arbitraire semblant correct f(x) = x² + 3x + valeur de base
        accrementation = int((level - 1) ** 2 + 3 * (level - 1))
#       augmentation de la vie de l'ennemi en augamentant ses pv_max
#       (point de vie maximum) et ses pv (point de vie)
        self.upgrade_max_vie(accrementation)

#       augmentation de ses dégats
        self.upgrade_damage(accrementation)
#           augmentaition de la vitesse des projectiles
        self.upgrade_projectils_velocity(accrementation)
#       On modifie son statut car il a été modifié
        self.mutation = True

#       fin de la procédure
        return
