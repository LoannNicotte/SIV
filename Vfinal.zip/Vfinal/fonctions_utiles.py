# -*- coding: utf-8 -*-
# le \ permet de continuer la ligne précédente à la ligne suivante

# =============================================================================
# importations:

import pygame
# =============================================================================

def add_txt(target_surf: pygame.Surface, txt: str, size: int, color: tuple, coord: tuple) -> None:
    """Procédure qui ajoute un texte de la taille et à la position que l'on\
    veut sur la surface que l'on veut.
    ----
    pre:
	    - target_surf est une surface pygame
        - txt est un str
        - size est un int
        - color est un tuple de 3 entier
        - coord est aussi un tuple
    post:
        - texte est une surface pygame
    """

#   Assertions
    assert type(target_surf) == pygame.Surface, "target_surf n'est pas une surface pygame"
    assert type(txt) == str, "txt n'est pas un str"
    assert type(size) == int, "size n'est pas un int"
    assert type(color) == tuple, "color n'est pas un tuple"
    assert len(color) == 3, "color n'a pas le bon nombre d'élément"
    assert type(coord) == tuple, "coord n'est pas un tuple"
    for i in range(2):
        assert type(color[i]) == int, "l'élément {} de color n'est pas un int".format(i)
        assert type(coord[i]) == int, "l'élément {} de coord n'est pas un int".format(i)
    assert type(color[2]) == int, "l'élement 2 de color n'est pas un int"

#   Transformation du texte en objet pygame
    texte = pygame.font.SysFont("assets/polices/Afterglow.ttf", size).render(txt, 1, color)

#   Assertion de fin
    assert type(texte) == pygame.Surface, "texte n'est pas une surface pygame"

#   On afiche cet surface pygame sur l'écran cible au coordonnées précisées en argument
    target_surf.blit(texte, coord)

#   Fin de la procédure
    return

def get_hight_score()->int:
    """fonction qui récupère le hight score enregistrer dans un fichier texte\
    externe
    ----
    pre:
        - None
    post:
        - hight_score est un int
    """

#   On ouvre le fichier en mode lecture
    with open("assets/save/score_max.txt", "r") as f:
#       On lit la première ligne qui contient le hight score on le transpose directement en int
        hight_score = int(f.readline())
#       On ferme le fichier
        f.close()

#   Assertion de fin
#   On verifie que hight_score est un int
    assert type(hight_score) == int, "hight_score n'est pas un int,\
        problème dans la fonction"

#   fin de la fonction, on retourne le hight_score en int
    return hight_score

def get_last_skin_avion()->str:
    """fonction qui retourne le chemin de la dernière apparence de l'avion\
    sélectionné
    ----
    pre:
        - None
    post:
        - skin_avion est un str
    """

#   on ouvre le fichier en mode lecture
    with open("assets/save/last_skins.txt", "r") as f:
#       On récupère la première ligne qui contient la dernière apparence séléctionné on ne la change pas car elles est
#       automatiquement un str
        skin_avion = f.readline()
#       On ferme le fichier
        f.close

#   Assertion de fin
#   0n verifie que skin_avion est un str
    assert type(skin_avion) == str, "skin_avion n'est pas un str"

#   fin de la fonction, on retourne skin_avion en str
    return skin_avion

def get_skins_enn()->list:
    """fonction qui retourne les 3 chemins des 3 apparences d'ennemis\
    sélectionnées dans une liste de 3 str
    ----
    pre:
        - None
    post:
        - skins est une list de 3 str
    """
#   on ouvre le fichier en mode lecture
    with open("assets/save/skins_ennemis.txt", "r") as f:
#       on extrait les lignes du fichier et on leur retire \n de fin
        skins = [i.rstrip() for i in f.readlines()]
#       on ferme le fichier
        f.close()

#   Assertions de fin
#   on vérifie que skins est une liste de 3 éléments qui sont des str
    assert type(skins) == list, "skins n'est pas une liste"
    assert len(skins) <= 3, "skins contient plus de 3 éléments"
    for i, j in enumerate(skins):
        assert type(j) == str, "l'élément {} de skins n'est pas un str".format(i)

#   fin de la fonction, on retourne skins
    return skins

def update_hight_score(score: int, hight_score: int = get_hight_score())->None:
    """procédure qui enregistre le meilleur score
    ----
    pre:
        - score est un int
        - hight_score est un int
    post:
        - None
    """

#   Assertions
    assert type(score) == int, "score n'est pas un int"
    assert type(hight_score) == int, "hight_score n'est pas un int"

#   on récupère les 2 valeurs en paramêtre
#   on regarde si le score du joueur est supérieur au meiileur score
    if score > hight_score:
#       on ouvre l'enregistrement en mode écriture
        with open('assets/save/score_max.txt', 'w') as f:
#           on écrit le score car il est le nouveau meilleur score
            f.write(str(score))
#           on ferme le fichier
            f.close()

#   fin de la procédure, si la condition est fausse, le meilleur score est toujpurs le même
    return

def update_skin_save(skin_avion_path: str = get_last_skin_avion())->None:
    """procédure qui enregistre le chemin de l'image de l'avion sélectionné
    ----
    pre:
        - skin_avion_way est un str
    post:
        - None
    """
#   Assertion
    assert type(skin_avion_path) == str, 'skins_avion_path n\'est pas un str'

#   on recupère le chemin de l'image en argument de la procédure
#   ouverture du fichier en mode écriture (cela écrase l'ancien contenu ou créer le fichier si celui ci n'existe encore
#   pas)
    with open("assets/save/last_skins.txt", "w") as f:
#       on écrit le nouveau chemin
        f.write(str(skin_avion_path))
#       on ferme le fichier
        f.close
#   fin de la procédure
    return

def update_skins(skins_ennemis: list = get_skins_enn())->None:
    """procédure qui enregistre les chemins des images selectionné
    ----
    pre:
        - skins_ennemis est une list de 3 str au plus
    post:
        - None
    """

#   Assertion
    assert type(skins_ennemis) == list, "skins_ennemis n'est pas une list"
#   on regarde si la liste ne dépasse pas la longueur normale qui est de 3
#   apparences
    assert len(skins_ennemis) <= 3, "trop de valeur dans skins_ennemis"
#   on vérifie qu'il s'agit d'une list de str
    for i, j in enumerate(skins_ennemis):
        assert type(j) == str, "l'élément {} de la list n'est pas un str".format(i)

#   on récupère la liste des ennemis sélectionné en paramêtre de la fonction

#   on ouvre le fichier en mode écriture (cela écrase l'ancien contenu)
    with open("assets/save/skins_ennemis.txt", "w") as f:
#       on écrit la nouvelle liste sous sa norme: une ligne par chemin
#       donc on joint la liste du séparatueur de ligne \n
        f.write("\n".join(skins_ennemis))
#       on ferme le fichier
        f.close()

#   fin de la procédure
    return

def reset_hight_score()->None:
    """procédure qui remets le meilleur score à 0, essentiellement fait pour\
    les développeurs
    ----
    pre:
        - None
    post:
        - None
    """
#   on ouvre le fichier en mode écriture
    with open("assets/save/score_max.txt","w") as f:
#       on écrit la nouvelle valeur: 0
        f.write("0")
#       on ferme le fichier
        f.close()
#   fin de la procédure
    return

def update_screen()->None:
    """fonction qui met à jour l'affichage de l'écran, qui l'actualise
    ----
    pre:
        - None
    post:
        - None
    """

#   actualistion
    pygame.display.flip()

#   fin de la procédure
    return

def make_cadenas_image_on_size(width: int, height: int) -> object:
    """fonction qui retourne une image de cademas de la hauteur et de la largeure donné en paramêtre
    ----
    pre:
        - width est un int > 0
        - height est un int > 0
    post:
        - image_returned est une instance de pygame.Surface
    """

#   importation
    import jeu

#   Assertions
    assert type(width) == int, "l'argument 0, width, n'est pas un int mais {}".format(type(width))
    assert type(height) == int, "l'argument 1, height, n'est pas un int mais {}".format(type(height))

    jeu = jeu.Jeu()
    image_returned = pygame.transform.scale(jeu.get_image_cadena(), (width, height))

#   Assertion
    assert type(image_returned) == pygame.Surface, "image_retourned n'est pas une instance de jeu.Jeu"

#   fin de la fonction
    return image_returned

def pause(screen: pygame.Surface,
        background: pygame.Surface = pygame.image.load("assets/general/fond.jpg"),
        run: bool = True,
        play: bool = True
    )->tuple:
    """fonction qui "met en pause" le programme et retourne la valeur de run à\
    son issue
    ----
    pre:
        - screen est une instance de pygame.Surface
        - background est une instance de pygame.Surface
        - run est un bool
        - play est un bool
    post:
        - False est un bool
        - run est un bool
    """
#    Importations
    import time

    from page_des_commandes import page_des_commandes
    from bouton_selectionnable import Bouton_selectionnable

#    Assertions
    assert isinstance(screen, pygame.Surface), "argument 0 must be a instance of pygame.Surface, not {}".format(type(screen))
    assert isinstance(background, pygame.Surface), "argument 1 must be a instance of pygame.Surface, not {}".format(type(background))
    assert isinstance(run, bool), "argument 2 must be a bool, not {}".format(type(run))
    assert isinstance(play, bool), "argument 3 must be a bool, not {}".format(type(play))

#   on regarde le temps qu'a duré la pause
    temps_start: float = time.time()

#    on charge l'image du fond pause à afficher
    bg_pause: pygame.Surface = pygame.image.load("assets/pause/fond_pause.png")

#    on intialises les boutons de choix
    resume: Bouton_selectionnable = Bouton_selectionnable(
        "resume",
        (
            pygame.image.load("assets/pause/pause_1-resume_game_no.png"),
            pygame.image.load("assets/pause/pause_1-resume_game_o.png")
        )
    )
    leave_game: Bouton_selectionnable = Bouton_selectionnable(
        "leave game",
        (
            pygame.image.load("assets/pause/pause_2-leave_game_no.png"),
            pygame.image.load("assets/pause/pause_2-leave_game_o.png")
        )
    )
    commandes: Bouton_selectionnable = Bouton_selectionnable(
        "commandes",
        (
            pygame.image.load('assets/pause/pause_3-commands_no.png'),
            pygame.image.load('assets/pause/pause_3-commands_o.png')
        )
    )
    running = True
    last = None
    while running:
        screen.blit(background, (0, 0))
        screen.blit(bg_pause, (0, 0))
        screen.blit(resume.get_image(), (280, 350))
        screen.blit(leave_game.get_image(), (280, 500))
        screen.blit(commandes.get_image(), (280, 650))
        update_screen()
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1 or event.key == pygame.K_KP1 \
                        or event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_2 or event.key == pygame.K_KP2:
                    running = False
                    play = False
                elif event.key == pygame.K_3 or event.key == pygame.K_KP3:
                    run = page_des_commandes(screen, background, run)
            elif event.type == pygame.QUIT:
                running = False
                play = False
                run = False
            elif event.type == pygame.MOUSEMOTION:
                x, y = event.pos
                if 280 < x < 640:
                    if 350 < y < 403:
                        resume.change_to_overflew()
                        last: Bouton_selectionnable = resume
                    elif 500 < y < 553:
                        leave_game.change_to_overflew()
                        last: Bouton_selectionnable = leave_game
                    elif 650 < y < 703:
                        commandes.change_to_overflew()
                        last: Bouton_selectionnable = commandes
                    elif last is not None:
                        last.change_to_norm()
                        last = None
                elif last is not None:
                    last.change_to_norm()
                    last = None
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if resume.get_overflew():
                    running = False
                    resume.change_to_norm()
                elif leave_game.get_overflew():
                    running = False
                    play = False
                    leave_game.change_to_norm()
                elif commandes.get_overflew():
                    page_des_commandes(screen, background, run)
                    commandes.change_to_norm()


#    Assertions
    assert isinstance(play, bool), "play is not a bool, but {}".format(type(play))
    assert isinstance(run, bool), "run is not a bool, but {}".format(type(run))

#    fin de la fonction
    return(play, run, (time.time() - temps_start))
