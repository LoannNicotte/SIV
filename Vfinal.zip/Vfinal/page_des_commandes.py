# -*- coding: utf-8 -*-
# le \ permet de continuer la ligne précédentes à la ligne suivantes

# =============================================================================
# importations

import pygame
# =============================================================================

def page_des_commandes(screen: pygame.Surface,
        background: pygame.Surface = pygame.transform.scale(pygame.image.load("assets/general/fond.jpg"), (920,900)),
        run: bool = True)->bool:
    """fonction qui affichage la page des commandes utiles pour jouer à\
    notre jeu, elle est uniquement consultative il y a comme interraction\
    le retourn au menu principal seulement. Cette fonction renvoie run pour\
    arrêter l'application si cela est demandé
    ----
    pre:
        - screen est une instance de pygame.Surface
        - background est une instance de pygame.Surface
        - run est un bool
    post:
        - run est un bool
    """

#   =============================================================================
#   importations

    import fonctions_utiles

    from bouton_selectionnable import Bouton_selectionnable
    from jeu import Jeu
#   =============================================================================

#   =============================================================================
#   Assertions

    assert isinstance(screen, pygame.Surface), "argument 0 must be a instance of pygame.Surface, not {}".format(type(screen))
    assert isinstance(background, pygame.Surface), "argument 1 must be a instance of pygame.Surface, not {}".format(type(background))
    assert isinstance(run, bool), "run must be a int, not {}".format(run)
#   =============================================================================

#   =============================================================================
#   initialisation des variables locales

#   play est la variable qui permet de faire boucler le programme jusqu'à ce
#   que l'on quitte la page
    play = True

#   on charge l'image à afficher
    image_des_commandes: pygame.Surface = pygame.transform.scale(
                    pygame.image.load("assets/pdc/page_des_commandes.png"),
                    (920, 850)
                    )
    jeu: Jeu = Jeu()
    close_button: Bouton_selectionnable = Bouton_selectionnable(
        "return to main Menu",
        jeu.get_images().get("return to main Menu")
    )

#   tant que l'on est sur la page
    while play:

#       =======================================================================
#       cette page est uniquement consultative, elle affiche une image et le bouton pour sortir de la page

#       On affiche le fond étoilé
        screen.blit(background, (0, 0))

#       On affiche l'image des commandes
        screen.blit(image_des_commandes, (0, 50))

#       On affiche le bouton
        screen.blit(close_button.get_image(), (2, 2))
#       =======================================================================

#       =======================================================================
#       update screen/mise à jour de l'affichage:

        fonctions_utiles.update_screen()
#       =======================================================================

#       pour les événements pris en compte par pygame
        for event in pygame.event.get():
#           si croix rouge de fermeture actionner
            if event.type == pygame.QUIT:
#               On quitte l'application
                play = False
                run = False

            elif event.type == pygame.MOUSEMOTION:
#               on récupère les nouvelles coordonnés de la souris
                x, y = event.pos

                if 2 < x < 237 and 2 < y < 37:
                    close_button.change_to_overflew()

                elif close_button.get_overflew():
                    close_button.change_to_norm()

            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if close_button.get_overflew():
                    play = False

            elif event.type == pygame.KEYDOWN:
#               si la touche escape (échap en français) est préssée, on
#               retourne au menu principal
                if event.key == pygame.K_ESCAPE:
#                   On arrete cette boucle interne
                    play = False
#   fin de la fonction
    return run


if __name__ == '__main__':
    pygame.init()
    pygame.display.set_caption("for Earth")
    format_screen = (920, 900)
    screen = pygame.display.set_mode(format_screen)

    run = page_des_commandes(screen)
    print(run)

    pygame.quit()
